-- =====================================================================
-- Registres de sécurité – MISE À JOUR v2
-- Historique des contrôles par année, résultat « non conforme »,
-- suivi des BAES et des extincteurs, paramètres et sauvegarde.
-- À exécuter dans Supabase > SQL Editor, APRÈS le premier script.
-- Peut être relancé sans risque.
-- =====================================================================

-- 1. Résultat « non conforme » (contrôle négatif)
alter table public.reg_rubriques drop constraint if exists reg_rubriques_resultat_check;
alter table public.reg_rubriques add constraint reg_rubriques_resultat_check
  check (resultat in ('', 'conforme', 'observations', 'non_conforme'));
alter table public.reg_visites drop constraint if exists reg_visites_resultat_check;
alter table public.reg_visites add constraint reg_visites_resultat_check
  check (resultat in ('', 'conforme', 'observations', 'non_conforme'));

-- 2. Historique : un contrôle par passage, pour retrouver chaque année
create table if not exists public.reg_controles (
  id            uuid primary key default gen_random_uuid(),
  site_id       text not null references public.reg_sites(id),
  rubrique_id   uuid not null references public.reg_rubriques(id) on delete cascade,
  date_controle date not null,
  intervenant   text not null default '',
  resultat      text not null default '' check (resultat in ('', 'conforme', 'observations', 'non_conforme')),
  reference     text not null default '',
  remarques     text not null default '',
  visite_id     uuid references public.reg_visites(id) on delete set null,
  cree_le       timestamptz not null default now(),
  cree_par      uuid default auth.uid() references public.profiles(id) on delete set null
);
create index if not exists reg_controles_site_date on public.reg_controles (site_id, date_controle desc);
create index if not exists reg_controles_rubrique on public.reg_controles (rubrique_id, date_controle desc);

-- 3. Équipements suivis (BAES et extincteurs) et leurs contrôles
create table if not exists public.reg_equipements (
  id                      uuid primary key default gen_random_uuid(),
  site_id                 text not null references public.reg_sites(id),
  categorie               text not null check (categorie in ('baes', 'extincteur')),
  code                    text not null check (length(trim(code)) > 0),
  zone                    text not null default '',
  emplacement             text not null default '',
  type_equipement         text not null default '',
  capacite                text not null default '',
  marque                  text not null default '',
  modele                  text not null default '',
  numero_serie            text not null default '',
  sati                    boolean not null default false,   -- BAES à autotest
  mise_en_service         date,
  batterie_remplacement   date,                             -- BAES : remplacement prévu de la batterie
  verification_annuelle   date,                             -- extincteur : prochaine vérification par le prestataire
  revision_decennale      date,                             -- extincteur : révision ou remplacement à 10 ans
  actif                   boolean not null default true,
  remarques               text not null default '',
  cree_le                 timestamptz not null default now(),
  unique (categorie, code)
);
create index if not exists reg_equipements_site on public.reg_equipements (site_id, categorie, zone, code);

create table if not exists public.reg_equip_controles (
  id             uuid primary key default gen_random_uuid(),
  equipement_id  uuid not null references public.reg_equipements(id) on delete cascade,
  date_controle  date not null default current_date,
  type_controle  text not null default 'mensuel' check (type_controle in ('mensuel', 'autonomie')),
  points         jsonb not null default '{}'::jsonb,
  conforme       boolean not null,
  remarques      text not null default '',
  cree_le        timestamptz not null default now(),
  cree_par       uuid default auth.uid() references public.profiles(id) on delete set null
);
create index if not exists reg_equip_controles_eq on public.reg_equip_controles (equipement_id, date_controle desc);

-- 4. Paramètres (une seule ligne)
create table if not exists public.reg_parametres (
  id                          smallint primary key default 1 check (id = 1),
  baes_frequence_jours        integer not null default 30  check (baes_frequence_jours between 1 and 365),
  autonomie_frequence_jours   integer not null default 182 check (autonomie_frequence_jours between 1 and 730),
  extincteur_frequence_jours  integer not null default 30  check (extincteur_frequence_jours between 1 and 365),
  derniere_sauvegarde         timestamptz,
  sauvegarde_par              uuid references public.profiles(id) on delete set null
);
insert into public.reg_parametres (id) values (1) on conflict (id) do nothing;

-- 5. Fonctions d'aide
create or replace function public.reg_site_de_equipement(d uuid) returns text
language sql stable security definer set search_path = public as $$
  select site_id from reg_equipements where id = d
$$;
grant execute on function public.reg_site_de_equipement(uuid) to authenticated;

-- 6. Sécurité
alter table public.reg_controles       enable row level security;
alter table public.reg_equipements     enable row level security;
alter table public.reg_equip_controles enable row level security;
alter table public.reg_parametres      enable row level security;
grant select, insert, update, delete on public.reg_controles, public.reg_equipements, public.reg_equip_controles to authenticated;
grant select, update on public.reg_parametres to authenticated;
revoke all on public.reg_controles, public.reg_equipements, public.reg_equip_controles, public.reg_parametres from anon;

drop policy if exists reg_controles_lire on public.reg_controles;
create policy reg_controles_lire on public.reg_controles for select to authenticated using (reg_can(site_id));
drop policy if exists reg_controles_ajouter on public.reg_controles;
create policy reg_controles_ajouter on public.reg_controles for insert to authenticated
  with check (reg_can(site_id) and reg_site_de_rubrique(rubrique_id) = site_id);
drop policy if exists reg_controles_modifier on public.reg_controles;
create policy reg_controles_modifier on public.reg_controles for update to authenticated
  using (reg_can(site_id) and (reg_is_admin() or cree_par = auth.uid()))
  with check (reg_can(site_id) and reg_site_de_rubrique(rubrique_id) = site_id);
drop policy if exists reg_controles_retirer on public.reg_controles;
create policy reg_controles_retirer on public.reg_controles for delete to authenticated
  using (reg_can(site_id) and (reg_is_admin() or cree_par = auth.uid()));

drop policy if exists reg_equipements_tout on public.reg_equipements;
create policy reg_equipements_tout on public.reg_equipements for all to authenticated
  using (reg_can(site_id)) with check (reg_can(site_id));

drop policy if exists reg_equip_controles_lire on public.reg_equip_controles;
create policy reg_equip_controles_lire on public.reg_equip_controles for select to authenticated
  using (reg_can(reg_site_de_equipement(equipement_id)));
drop policy if exists reg_equip_controles_ajouter on public.reg_equip_controles;
create policy reg_equip_controles_ajouter on public.reg_equip_controles for insert to authenticated
  with check (reg_can(reg_site_de_equipement(equipement_id)) and cree_par = auth.uid());
drop policy if exists reg_equip_controles_retirer on public.reg_equip_controles;
create policy reg_equip_controles_retirer on public.reg_equip_controles for delete to authenticated
  using (reg_can(reg_site_de_equipement(equipement_id)) and (reg_is_admin() or cree_par = auth.uid()));

drop policy if exists reg_parametres_lire on public.reg_parametres;
create policy reg_parametres_lire on public.reg_parametres for select to authenticated
  using (cardinality(reg_mes_sites()) > 0);
drop policy if exists reg_parametres_modifier on public.reg_parametres;
create policy reg_parametres_modifier on public.reg_parametres for update to authenticated
  using (reg_is_admin()) with check (reg_is_admin());

-- 7. Reprise : les contrôles déjà saisis entrent dans l'historique
insert into public.reg_controles (site_id, rubrique_id, date_controle, intervenant, resultat, reference, cree_le, cree_par)
select r.site_id, r.id, r.dernier, r.intervenant, r.resultat, r.reference, coalesce(r.maj_le, now()), r.maj_par
from public.reg_rubriques r
where r.dernier is not null
  and not exists (select 1 from public.reg_controles c where c.rubrique_id = r.id and c.date_controle = r.dernier);

insert into public.reg_controles (site_id, rubrique_id, date_controle, intervenant, resultat, remarques, visite_id, cree_le, cree_par)
select v.site_id, v.rubrique_id, v.date_visite, v.entreprise || ' (' || v.intervenant || ')', v.resultat, v.remarques, v.id, v.signe_le, v.vise_par
from public.reg_visites v
where v.rubrique_id is not null
  and not exists (select 1 from public.reg_controles c where c.visite_id = v.id);

-- Fin. Message attendu : « Success. No rows returned ».
