-- =====================================================================
-- Stock Entretien – Secteur Schiltigheim
-- Base de données Supabase : tables, sécurité et fonctions
-- À coller en entier dans Supabase > SQL Editor, puis « Run ».
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. TABLES
-- ---------------------------------------------------------------------

create table if not exists public.sites (
  id         smallint primary key,
  name       text not null unique,
  short_name text not null
);

create table if not exists public.profiles (
  id         uuid primary key references auth.users(id) on delete cascade,
  full_name  text not null default '',
  role       text not null default 'agent'
             check (role in ('secteur', 'responsable', 'agent')),
  site_id    smallint references public.sites(id),
  active     boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id          uuid primary key default gen_random_uuid(),
  code        text not null unique check (code ~ '^[A-Z0-9-]{2,20}$'),
  name        text not null,
  family      text not null,
  packaging   text not null default '',
  bpu_line    integer,
  adelya_ref  text not null default '',
  chemical    boolean not null default false,
  -- Sécurité
  signal_word text not null default '' check (signal_word in ('', 'Danger', 'Attention')),
  pictograms  text[] not null default '{}',
  ppe         text[] not null default '{}',
  hazards     text not null default '',
  first_aid   text not null default '',
  incompat    text not null default '',
  storage     text not null default '',
  -- Prévu pour plus tard (budget), masqué dans l'application
  unit_price  numeric(10,2),
  active      boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

-- Stock d'un produit sur un site
create table if not exists public.stocks (
  product_id    uuid not null references public.products(id) on delete cascade,
  site_id       smallint not null references public.sites(id),
  quantity      numeric(12,2) not null default 0 check (quantity >= 0),
  min_quantity  numeric(12,2) not null default 0 check (min_quantity >= 0),
  safety_margin numeric(12,2) not null default 0 check (safety_margin >= 0),
  location      text not null default '',
  updated_at    timestamptz not null default now(),
  primary key (product_id, site_id)
);

-- Pages de fiches de sécurité (photos ou PDF)
create table if not exists public.safety_sheets (
  id          uuid primary key default gen_random_uuid(),
  product_id  uuid not null references public.products(id) on delete cascade,
  file_path   text not null,
  file_name   text not null default '',
  page        integer not null default 1,
  uploaded_by uuid references public.profiles(id),
  created_at  timestamptz not null default now()
);

-- Demandes des agents
create table if not exists public.requests (
  id            uuid primary key default gen_random_uuid(),
  site_id       smallint not null references public.sites(id),
  requested_by  uuid not null references public.profiles(id),
  status        text not null default 'en_attente'
                check (status in ('en_attente', 'validee', 'refusee', 'annulee')),
  note          text not null default '',
  refuse_reason text not null default '',
  handled_by    uuid references public.profiles(id),
  handled_at    timestamptz,
  created_at    timestamptz not null default now()
);

create table if not exists public.request_items (
  id          uuid primary key default gen_random_uuid(),
  request_id  uuid not null references public.requests(id) on delete cascade,
  product_id  uuid not null references public.products(id),
  quantity    numeric(12,2) not null check (quantity > 0),
  given       numeric(12,2)
);

-- Mouvements de stock (journal, jamais modifié)
create table if not exists public.movements (
  id           uuid primary key default gen_random_uuid(),
  site_id      smallint not null references public.sites(id),
  product_id   uuid not null references public.products(id),
  kind         text not null check (kind in ('entree', 'sortie', 'inventaire')),
  quantity     numeric(12,2) not null,            -- quantité saisie (comptée pour un inventaire)
  delta        numeric(12,2) not null,            -- variation réelle du stock
  stock_before numeric(12,2) not null,
  stock_after  numeric(12,2) not null,
  request_id   uuid references public.requests(id),
  reference    text not null default '',          -- n° de bon de livraison
  note         text not null default '',
  user_id      uuid not null references public.profiles(id),
  created_at   timestamptz not null default now()
);

create index if not exists movements_site_date on public.movements (site_id, created_at desc);
create index if not exists movements_product   on public.movements (product_id, created_at desc);
create index if not exists requests_site_status on public.requests (site_id, status);

-- Réglages (dates des commandes)
create table if not exists public.settings (
  id               smallint primary key default 1 check (id = 1),
  next_order       date not null default '2027-03-15',
  following_order  date not null default '2027-10-15',
  updated_at       timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- 2. FONCTIONS D'AIDE (rôle de la personne connectée)
-- ---------------------------------------------------------------------

create or replace function public.my_role() returns text
language sql stable security definer set search_path = public as $$
  select role from profiles where id = auth.uid() and active
$$;

create or replace function public.my_site() returns smallint
language sql stable security definer set search_path = public as $$
  select site_id from profiles where id = auth.uid() and active
$$;

create or replace function public.is_secteur() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(my_role() = 'secteur', false)
$$;

-- Peut voir un site : le secteur voit tout, les autres leur site
create or replace function public.can_see_site(s smallint) returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(my_role() = 'secteur' or my_site() = s, false)
$$;

-- Peut faire bouger le stock d'un site
create or replace function public.can_manage_site(s smallint) returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(my_role() = 'secteur' or (my_role() = 'responsable' and my_site() = s), false)
$$;

-- ---------------------------------------------------------------------
-- 3. AUTOMATISMES
-- ---------------------------------------------------------------------

-- Nouveau compte : création du profil. Le tout premier compte devient
-- automatiquement responsable de secteur, actif. Les suivants attendent
-- d'être validés.
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  first_user boolean;
begin
  perform pg_advisory_xact_lock(42);
  select not exists (select 1 from profiles) into first_user;
  insert into profiles (id, full_name, role, active)
  values (
    new.id,
    coalesce(nullif(trim(new.raw_user_meta_data->>'full_name'), ''), split_part(new.email, '@', 1)),
    case when first_user then 'secteur' else 'agent' end,
    first_user
  );
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Nouveau produit : une ligne de stock à zéro sur chaque site
create or replace function public.handle_new_product() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into stocks (product_id, site_id)
  select new.id, s.id from sites s
  on conflict do nothing;
  return new;
end $$;

drop trigger if exists on_product_created on public.products;
create trigger on_product_created
  after insert on public.products
  for each row execute function public.handle_new_product();

create or replace function public.touch_updated_at() returns trigger
language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end $$;

drop trigger if exists products_touch on public.products;
create trigger products_touch before update on public.products
  for each row execute function public.touch_updated_at();

-- Un utilisateur ne peut pas modifier son propre rôle, site ou statut
create or replace function public.guard_profile_update() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if not is_secteur() then
    if new.role is distinct from old.role
       or new.site_id is distinct from old.site_id
       or new.active is distinct from old.active then
      raise exception 'Seul le responsable de secteur peut modifier les rôles et les accès.';
    end if;
  end if;
  return new;
end $$;

drop trigger if exists profiles_guard on public.profiles;
create trigger profiles_guard before update on public.profiles
  for each row execute function public.guard_profile_update();

-- ---------------------------------------------------------------------
-- 4. OPÉRATIONS SUR LE STOCK (toutes atomiques)
-- ---------------------------------------------------------------------

-- Cœur : applique un mouvement en verrouillant la ligne de stock.
create or replace function public._apply_movement(
  p_site smallint, p_product uuid, p_kind text, p_qty numeric,
  p_reference text, p_note text, p_request uuid
) returns public.movements
language plpgsql security definer set search_path = public as $$
declare
  v_before numeric;
  v_after  numeric;
  v_mov    movements;
begin
  if p_qty is null or p_qty < 0 or (p_kind <> 'inventaire' and p_qty = 0) then
    raise exception 'Quantité invalide.';
  end if;

  select quantity into v_before from stocks
   where product_id = p_product and site_id = p_site
   for update;
  if not found then
    raise exception 'Produit inconnu sur ce site.';
  end if;

  v_after := case p_kind
    when 'entree'     then v_before + p_qty
    when 'sortie'     then v_before - p_qty
    when 'inventaire' then p_qty
  end;

  if v_after < 0 then
    raise exception 'Stock insuffisant : il reste % pour ce produit.', v_before;
  end if;

  update stocks set quantity = v_after, updated_at = now()
   where product_id = p_product and site_id = p_site;

  insert into movements (site_id, product_id, kind, quantity, delta, stock_before, stock_after,
                         request_id, reference, note, user_id)
  values (p_site, p_product, p_kind, p_qty, v_after - v_before, v_before, v_after,
          p_request, coalesce(p_reference, ''), coalesce(p_note, ''), auth.uid())
  returning * into v_mov;
  return v_mov;
end $$;

revoke all on function public._apply_movement(smallint, uuid, text, numeric, text, text, uuid) from public, anon, authenticated;

-- Entrée, sortie directe ou inventaire d'un produit
create or replace function public.record_movement(
  p_site smallint, p_product uuid, p_kind text, p_qty numeric,
  p_reference text default '', p_note text default ''
) returns public.movements
language plpgsql security definer set search_path = public as $$
begin
  if not can_manage_site(p_site) then
    raise exception 'Vous n''avez pas les droits pour modifier le stock de ce site.';
  end if;
  if p_kind not in ('entree', 'sortie', 'inventaire') then
    raise exception 'Type de mouvement invalide.';
  end if;
  return _apply_movement(p_site, p_product, p_kind, p_qty, p_reference, p_note, null);
end $$;

-- Plusieurs lignes d'un coup (livraison, inventaire complet).
-- p_lines = [{"product_id": "...", "quantity": 3}, ...]  — tout ou rien.
create or replace function public.record_movements(
  p_site smallint, p_kind text, p_lines jsonb,
  p_reference text default '', p_note text default ''
) returns integer
language plpgsql security definer set search_path = public as $$
declare
  l jsonb;
  n integer := 0;
begin
  if not can_manage_site(p_site) then
    raise exception 'Vous n''avez pas les droits pour modifier le stock de ce site.';
  end if;
  if p_kind not in ('entree', 'sortie', 'inventaire') then
    raise exception 'Type de mouvement invalide.';
  end if;
  for l in select * from jsonb_array_elements(p_lines) loop
    perform _apply_movement(p_site, (l->>'product_id')::uuid, p_kind,
                            (l->>'quantity')::numeric, p_reference, p_note, null);
    n := n + 1;
  end loop;
  return n;
end $$;

-- Un agent (ou un responsable) crée une demande
-- p_items = [{"product_id": "...", "quantity": 2}, ...]
create or replace function public.create_request(p_items jsonb, p_note text default '')
returns uuid
language plpgsql security definer set search_path = public as $$
declare
  v_site smallint := my_site();
  v_id   uuid;
  i      jsonb;
begin
  if my_role() is null then
    raise exception 'Votre compte n''est pas encore validé.';
  end if;
  if v_site is null then
    raise exception 'Aucun site n''est associé à votre compte.';
  end if;
  if jsonb_array_length(coalesce(p_items, '[]'::jsonb)) = 0 then
    raise exception 'La demande est vide.';
  end if;
  insert into requests (site_id, requested_by, note)
  values (v_site, auth.uid(), coalesce(p_note, ''))
  returning id into v_id;
  for i in select * from jsonb_array_elements(p_items) loop
    insert into request_items (request_id, product_id, quantity)
    values (v_id, (i->>'product_id')::uuid, (i->>'quantity')::numeric);
  end loop;
  return v_id;
end $$;

-- Le responsable valide : remet les quantités (éventuellement ajustées)
-- p_given = [{"item_id": "...", "given": 2}, ...]  (0 = rien remis pour cette ligne)
create or replace function public.validate_request(p_request uuid, p_given jsonb)
returns void
language plpgsql security definer set search_path = public as $$
declare
  r  requests;
  g  jsonb;
  it request_items;
  v_given numeric;
begin
  select * into r from requests where id = p_request for update;
  if not found then raise exception 'Demande introuvable.'; end if;
  if not can_manage_site(r.site_id) then
    raise exception 'Vous n''avez pas les droits pour valider cette demande.';
  end if;
  if r.status <> 'en_attente' then
    raise exception 'Cette demande a déjà été traitée.';
  end if;

  for it in select * from request_items where request_id = p_request loop
    v_given := it.quantity;
    for g in select * from jsonb_array_elements(coalesce(p_given, '[]'::jsonb)) loop
      if (g->>'item_id')::uuid = it.id then
        v_given := (g->>'given')::numeric;
      end if;
    end loop;
    if v_given < 0 then raise exception 'Quantité remise invalide.'; end if;
    update request_items set given = v_given where id = it.id;
    if v_given > 0 then
      perform _apply_movement(r.site_id, it.product_id, 'sortie', v_given, '',
                              'Demande', p_request);
    end if;
  end loop;

  update requests set status = 'validee', handled_by = auth.uid(), handled_at = now()
   where id = p_request;
end $$;

create or replace function public.refuse_request(p_request uuid, p_reason text)
returns void
language plpgsql security definer set search_path = public as $$
declare
  r requests;
begin
  select * into r from requests where id = p_request for update;
  if not found then raise exception 'Demande introuvable.'; end if;
  if not can_manage_site(r.site_id) then
    raise exception 'Vous n''avez pas les droits pour refuser cette demande.';
  end if;
  if r.status <> 'en_attente' then
    raise exception 'Cette demande a déjà été traitée.';
  end if;
  update requests set status = 'refusee', refuse_reason = coalesce(p_reason, ''),
         handled_by = auth.uid(), handled_at = now()
   where id = p_request;
end $$;

-- L'agent annule sa propre demande tant qu'elle est en attente
create or replace function public.cancel_request(p_request uuid)
returns void
language plpgsql security definer set search_path = public as $$
begin
  update requests set status = 'annulee', handled_at = now()
   where id = p_request and requested_by = auth.uid() and status = 'en_attente';
  if not found then
    raise exception 'Cette demande ne peut plus être annulée.';
  end if;
end $$;

grant execute on function public.record_movement(smallint, uuid, text, numeric, text, text) to authenticated;
grant execute on function public.record_movements(smallint, text, jsonb, text, text) to authenticated;
grant execute on function public.create_request(jsonb, text) to authenticated;
grant execute on function public.validate_request(uuid, jsonb) to authenticated;
grant execute on function public.refuse_request(uuid, text) to authenticated;
grant execute on function public.cancel_request(uuid) to authenticated;

-- Ping hebdomadaire (évite la mise en pause du projet gratuit)
create or replace function public.ping() returns text
language sql security definer set search_path = public as $$
  select 'ok ' || count(*)::text from sites
$$;
grant execute on function public.ping() to anon, authenticated;

-- ---------------------------------------------------------------------
-- 5. SÉCURITÉ (Row Level Security)
-- ---------------------------------------------------------------------

alter table public.sites          enable row level security;
alter table public.profiles       enable row level security;
alter table public.products       enable row level security;
alter table public.stocks         enable row level security;
alter table public.safety_sheets  enable row level security;
alter table public.requests       enable row level security;
alter table public.request_items  enable row level security;
alter table public.movements      enable row level security;
alter table public.settings       enable row level security;

-- Sites : lisibles par tout utilisateur connecté
drop policy if exists sites_read on public.sites;
create policy sites_read on public.sites for select to authenticated using (true);

-- Profils : chacun voit le sien ; les comptes validés voient les noms des collègues
drop policy if exists profiles_read on public.profiles;
create policy profiles_read on public.profiles for select to authenticated
  using (id = auth.uid() or my_role() is not null);
drop policy if exists profiles_update_self on public.profiles;
create policy profiles_update_self on public.profiles for update to authenticated
  using (id = auth.uid() or is_secteur()) with check (id = auth.uid() or is_secteur());
drop policy if exists profiles_delete on public.profiles;
create policy profiles_delete on public.profiles for delete to authenticated
  using (is_secteur() and id <> auth.uid());

-- Produits : lus par tous les comptes validés, gérés par le secteur
drop policy if exists products_read on public.products;
create policy products_read on public.products for select to authenticated
  using (my_role() is not null);
drop policy if exists products_write on public.products;
create policy products_write on public.products for all to authenticated
  using (is_secteur()) with check (is_secteur());

-- Stocks : lus sur son site (tout pour le secteur). Seuils et emplacement
-- modifiables par le responsable du site ; la quantité ne change que par
-- les fonctions ci-dessus.
drop policy if exists stocks_read on public.stocks;
create policy stocks_read on public.stocks for select to authenticated
  using (can_see_site(site_id));
drop policy if exists stocks_update on public.stocks;
create policy stocks_update on public.stocks for update to authenticated
  using (can_manage_site(site_id)) with check (can_manage_site(site_id));
revoke update on public.stocks from authenticated;
grant update (min_quantity, safety_margin, location) on public.stocks to authenticated;
revoke insert, delete on public.stocks from authenticated;

-- Fiches de sécurité : lues par tous, gérées par le secteur
drop policy if exists sheets_read on public.safety_sheets;
create policy sheets_read on public.safety_sheets for select to authenticated
  using (my_role() is not null);
drop policy if exists sheets_write on public.safety_sheets;
create policy sheets_write on public.safety_sheets for all to authenticated
  using (is_secteur()) with check (is_secteur());

-- Demandes : l'agent voit les siennes, le responsable celles de son site
drop policy if exists requests_read on public.requests;
create policy requests_read on public.requests for select to authenticated
  using (requested_by = auth.uid() or can_manage_site(site_id));
drop policy if exists items_read on public.request_items;
create policy items_read on public.request_items for select to authenticated
  using (exists (select 1 from requests r where r.id = request_id
                 and (r.requested_by = auth.uid() or can_manage_site(r.site_id))));

-- Mouvements : lecture seule, sur son site
drop policy if exists movements_read on public.movements;
create policy movements_read on public.movements for select to authenticated
  using (can_see_site(site_id));

-- Réglages : lus par tous, modifiés par le secteur
drop policy if exists settings_read on public.settings;
create policy settings_read on public.settings for select to authenticated using (true);
drop policy if exists settings_write on public.settings;
create policy settings_write on public.settings for update to authenticated
  using (is_secteur()) with check (is_secteur());

-- Aucune écriture directe dans les journaux
revoke insert, update, delete on public.movements, public.requests, public.request_items from authenticated, anon;

-- ---------------------------------------------------------------------
-- 6. STOCKAGE DES FICHES DE SÉCURITÉ (photos, PDF)
-- ---------------------------------------------------------------------

insert into storage.buckets (id, name, public)
values ('fiches-securite', 'fiches-securite', false)
on conflict (id) do nothing;

drop policy if exists fds_read on storage.objects;
create policy fds_read on storage.objects for select to authenticated
  using (bucket_id = 'fiches-securite' and public.my_role() is not null);
drop policy if exists fds_insert on storage.objects;
create policy fds_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'fiches-securite' and public.is_secteur());
drop policy if exists fds_delete on storage.objects;
create policy fds_delete on storage.objects for delete to authenticated
  using (bucket_id = 'fiches-securite' and public.is_secteur());

-- ---------------------------------------------------------------------
-- 7. DONNÉES DE DÉPART
-- ---------------------------------------------------------------------

insert into public.sites (id, name, short_name) values
  (1, 'Centre sportif Nelson Mandela', 'Mandela'),
  (2, 'Complexe de l''Aar', 'Aar')
on conflict (id) do nothing;

insert into public.settings (id) values (1) on conflict (id) do nothing;
