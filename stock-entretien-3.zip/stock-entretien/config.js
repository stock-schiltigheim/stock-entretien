// =====================================================================
// Réglages de connexion à Supabase
// Remplacez les deux valeurs ci-dessous par celles de votre projet
// (Supabase > Project Settings > API Keys / Data API).
// =====================================================================

window.STOCK_CONFIG = {
  // « Project URL », par exemple : https://abcdefghijkl.supabase.co
  supabaseUrl: "https://emjvcirqslewqpyxjqbs.supabase.co",

  // Clé publique : « publishable key » (commence par sb_publishable_)
  // ou, sur les anciens projets, « anon public » (commence par eyJ).
  // Ne jamais mettre ici la clé « secret » ou « service_role ».
  supabaseAnonKey: "sb_publishable_Yy7vh7RkxNZum9gbGuzBGQ_z6wr7ndW",
};
