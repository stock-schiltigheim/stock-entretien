/* =====================================================================
   Stock Entretien — Secteur Schiltigheim
   Application de suivi des produits d'entretien (Mandela, Aar)
   ===================================================================== */
(() => {
'use strict';

// ---------------------------------------------------------------------
// Outils
// ---------------------------------------------------------------------
const CFG = window.STOCK_CONFIG || {};
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const main = $('#main');
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const nf = new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 2 });
const fmt = (n) => nf.format(Number(n) || 0);
const dfTime = new Intl.DateTimeFormat('fr-FR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
const dfHour = new Intl.DateTimeFormat('fr-FR', { hour: '2-digit', minute: '2-digit' });
const dfDay = new Intl.DateTimeFormat('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' });
const dfDate = new Intl.DateTimeFormat('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });
const dfShort = new Intl.DateTimeFormat('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' });
const parseNum = (v) => {
  const n = parseFloat(String(v ?? '').replace(',', '.').replace(/\s/g, ''));
  return Number.isFinite(n) ? n : NaN;
};
const round2 = (n) => Math.round(n * 100) / 100;
const DAY = 86400000;
const cap = (s) => (s ? s.charAt(0).toUpperCase() + s.slice(1) : s);
const isoDate = (d) => {
  const z = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
  return z.toISOString().slice(0, 10);
};
const lsGet = (k, d) => { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch { return d; } };
const lsSet = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* stockage indisponible */ } };
const lsDel = (k) => { try { localStorage.removeItem(k); } catch { /* rien */ } };

function errMsg(e) {
  const m = (e && (e.message || e.error_description || e.msg)) || String(e || '');
  if (/fetch|network|NetworkError|Load failed/i.test(m)) return 'Pas de connexion. Vérifiez le réseau et réessayez.';
  if (/Invalid login credentials/i.test(m)) return 'E-mail ou mot de passe incorrect.';
  if (/already registered|already exists/i.test(m)) return 'Un compte existe déjà avec cet e-mail. Connectez-vous.';
  if (/Password should be at least/i.test(m)) return 'Le mot de passe doit contenir au moins 6 caractères.';
  if (/Email not confirmed/i.test(m)) return 'Adresse e-mail pas encore confirmée.';
  if (/rate limit/i.test(m)) return 'Trop de tentatives. Patientez quelques minutes.';
  if (/duplicate key.*code/i.test(m)) return 'Ce code produit existe déjà.';
  if (/permission denied|row-level security/i.test(m)) return 'Vous n\'avez pas les droits pour cette action.';
  return m.replace(/^ERROR:\s*/, '');
}

// ---------------------------------------------------------------------
// Icônes
// ---------------------------------------------------------------------
const I = (p, extra = '') => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" ${extra}>${p}</svg>`;
const ICON = {
  home: I('<path d="M3 11.5 12 4l9 7.5"/><path d="M5 10v10h5v-6h4v6h5V10"/>'),
  ask: I('<path d="M6 6h15l-1.5 9h-12z"/><path d="M6 6 5 3H2"/><circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/>'),
  scan: I('<path d="M4 8V5a1 1 0 0 1 1-1h3M16 4h3a1 1 0 0 1 1 1v3M20 16v3a1 1 0 0 1-1 1h-3M8 20H5a1 1 0 0 1-1-1v-3"/><path d="M7 12h10"/>'),
  stock: I('<path d="M3 7l9-4 9 4-9 4z"/><path d="M3 7v10l9 4 9-4V7"/><path d="M12 11v10"/>'),
  history: I('<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l3 2"/>'),
  more: I('<circle cx="5" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="19" cy="12" r="1.5"/>'),
  shield: I('<path d="M12 3 4 6v6c0 4.5 3.4 8.4 8 9 4.6-.6 8-4.5 8-9V6z"/><path d="M12 8v4M12 16h.01"/>'),
  out: I('<path d="M12 15V3M7 8l5-5 5 5"/><path d="M4 14v5a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-5"/>'),
  in: I('<path d="M12 3v12M7 10l5 5 5-5"/><path d="M4 14v5a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-5"/>'),
  count: I('<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4V3h6v1M9 10h6M9 14h6M9 18h3"/>'),
  users: I('<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><path d="M16 4.5a3.5 3.5 0 0 1 0 7M21.5 20a6.5 6.5 0 0 0-4-6"/>'),
  order: I('<path d="M4 4h16v16H4z"/><path d="M8 9h8M8 13h8M8 17h5"/>'),
  download: I('<path d="M12 4v12M7 11l5 5 5-5"/><path d="M5 20h14"/>'),
  tag: I('<path d="M3 3h8l10 10-8 8L3 11z"/><circle cx="7.5" cy="7.5" r="1.5"/>'),
  search: I('<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>'),
  back: I('<path d="m15 18-6-6 6-6"/>'),
  camera: I('<path d="M4 8h3l2-3h6l2 3h3a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1z"/><circle cx="12" cy="13.5" r="3.5"/>'),
  file: I('<path d="M14 3H6a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V8z"/><path d="M14 3v5h5"/>'),
  user: I('<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>'),
  products: I('<path d="M9 3h6v4l2 3v10a1 1 0 0 1-1 1H8a1 1 0 0 1-1-1V10l2-3z"/><path d="M7 14h10"/>'),
  plus: I('<path d="M12 5v14M5 12h14"/>'),
  chevron: I('<path d="m9 6 6 6-6 6"/>'),
};

// ---------------------------------------------------------------------
// Sécurité : pictogrammes SGH et équipements de protection
// ---------------------------------------------------------------------
const PICTOS = {
  GHS01: { label: 'Explosif', g: '<circle cx="50" cy="57" r="9" fill="#000"/><path d="M50 32v10M50 72v6M30 57h9M61 57h9M36 43l6 6M58 65l6 6M64 43l-6 6M36 71l6-6" stroke="#000" stroke-width="4" stroke-linecap="round"/>' },
  GHS02: { label: 'Inflammable', g: '<path d="M50 26c7 11 15 17 13 30-1 9-7 14-13 14-8 0-14-6-13-15 1-8 7-11 8-19 3 4 5 8 5 12 4-5 3-14 0-22z" fill="#000"/><rect x="34" y="72" width="32" height="4" fill="#000"/>' },
  GHS03: { label: 'Comburant', g: '<circle cx="50" cy="62" r="10" fill="none" stroke="#000" stroke-width="5"/><path d="M50 28c5 7 9 11 8 18-1 5-4 7-8 7s-8-3-7-8c0-5 4-7 5-11 2 2 3 4 3 7 2-4 1-9-1-13z" fill="#000"/><rect x="34" y="75" width="32" height="4" fill="#000"/>' },
  GHS04: { label: 'Gaz sous pression', g: '<rect x="30" y="44" width="40" height="18" rx="9" fill="#000"/><rect x="68" y="49" width="6" height="8" fill="#000"/>' },
  GHS05: { label: 'Corrosif', g: '<g fill="#000"><rect x="27" y="27" width="8" height="19" rx="2" transform="rotate(-40 31 36)"/><rect x="64" y="27" width="8" height="19" rx="2" transform="rotate(40 68 36)"/><circle cx="39" cy="52" r="2.6"/><circle cx="40" cy="59" r="2.2"/><circle cx="60" cy="52" r="2.6"/><circle cx="59" cy="59" r="2.2"/><path d="M26 66h22v4l-3 2-3-2-3 2-3-2-3 2-3-2-4 2z"/><path d="M53 64c4 0 6 2 9 2h10v8H56c-2 0-4-1-5-3z"/></g>' },
  GHS06: { label: 'Toxique', g: '<circle cx="50" cy="44" r="12" fill="#000"/><circle cx="45" cy="43" r="3" fill="#fff"/><circle cx="55" cy="43" r="3" fill="#fff"/><path d="M34 60l32 14M66 60 34 74" stroke="#000" stroke-width="5" stroke-linecap="round"/>' },
  GHS07: { label: 'Irritant, nocif', g: '<rect x="46" y="27" width="8" height="31" rx="3" fill="#000"/><circle cx="50" cy="68" r="5" fill="#000"/>' },
  GHS08: { label: 'Danger pour la santé', g: '<circle cx="50" cy="32" r="6" fill="#000"/><path d="M38 76V52c0-8 5-12 12-12s12 4 12 12v24z" fill="#000"/><path d="M44 56l6 6 6-6-6 10z" fill="#fff"/>' },
  GHS09: { label: 'Environnement', g: '<path d="M36 64V44M36 50l-6-6M36 54l6-6" stroke="#000" stroke-width="4" stroke-linecap="round"/><path d="M48 66c6-6 14-6 20 0-6 6-14 6-20 0zM68 66l5-4v8z" fill="#000"/><path d="M28 73h44" stroke="#000" stroke-width="3"/>' },
};
const picto = (code, size) => {
  const p = PICTOS[code];
  if (!p) return '';
  return `<svg viewBox="0 0 100 100" ${size ? `width="${size}" height="${size}"` : ''} role="img" aria-label="${esc(p.label)}"><polygon points="50,5 95,50 50,95 5,50" fill="#fff" stroke="#D40000" stroke-width="7" stroke-linejoin="round"/>${p.g}</svg>`;
};
const PPE = ['Gants', 'Lunettes', 'Masque', 'Blouse ou tablier', 'Chaussures de sécurité', 'Aérer le local'];

// ---------------------------------------------------------------------
// État
// ---------------------------------------------------------------------
const S = {
  sb: null,
  me: null,
  sites: [],
  site: null,
  products: [],
  byCode: {},
  byId: {},
  profiles: {},
  settings: null,
  pending: 0,
  pendingUsers: 0,
  cart: lsGet('stock.cart', {}),
  tok: 0,
  stream: null,
  scanRAF: 0,
  draftIn: {},
  draftInRef: '',
  filters: { stockFam: 'Tout', stockQ: '', askFam: 'Tout', askQ: '', histPeriod: 30, histKind: 'tout', histQ: '' },
};
const role = () => S.me?.role;
const isSecteur = () => role() === 'secteur';
const isResp = () => role() === 'responsable' || role() === 'secteur';
const canManage = (site = S.site) => isSecteur() || (role() === 'responsable' && S.me.site_id === site);
const siteName = (id) => S.sites.find((s) => s.id === id)?.name || '';
const siteShort = (id) => S.sites.find((s) => s.id === id)?.short_name || '';
const personName = (id) => S.profiles[id]?.full_name || (id === S.me?.id ? S.me.full_name : 'Utilisateur');
const firstName = (n) => String(n || '').trim().split(/\s+/)[0] || '';

function stockOf(p, site = S.site) {
  return p.stockBy[site] || { quantity: 0, min_quantity: 0, safety_margin: 0, location: '' };
}
function status(st) {
  const q = Number(st.quantity), m = Number(st.min_quantity);
  if (q <= 0) return 'rupture';
  if (m > 0 && q <= m) return 'bas';
  return 'ok';
}
const STATUS_LABEL = { ok: 'En stock', bas: 'Stock bas', rupture: 'Épuisé' };
const isAlert = (p, site = S.site) => {
  const st = stockOf(p, site);
  return Number(st.min_quantity) > 0 && Number(st.quantity) <= Number(st.min_quantity);
};
const activeProducts = () => S.products.filter((p) => p.active);
const FAMILY_ORDER = ['Sols', 'Sanitaires', 'Surfaces et vitres', 'Mains', 'Papier', 'Sacs poubelle', 'Protection', 'Petit matériel', 'Matériel'];
const famRank = (f) => { const i = FAMILY_ORDER.indexOf(f); return i < 0 ? 99 : i; };
const families = () => [...new Set(activeProducts().map((p) => p.family))].sort((a, b) => famRank(a) - famRank(b) || a.localeCompare(b));

// ---------------------------------------------------------------------
// Interface commune : toast, feuille, onglets
// ---------------------------------------------------------------------
let toastTimer = 0;
function toast(msg, isError = false) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.toggle('error', isError);
  t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.hidden = true; }, isError ? 5000 : 2800);
}

let sheetCleanup = null;
function openSheet(html, mount) {
  const sheet = $('#sheet');
  $('#sheet-body').innerHTML = html;
  sheet.hidden = false;
  document.body.style.overflow = 'hidden';
  sheetCleanup = mount ? mount($('#sheet-body')) || null : null;
  const f = $('#sheet-body [autofocus]');
  if (f) setTimeout(() => f.focus(), 60);
}
function closeSheet() {
  const sheet = $('#sheet');
  if (sheet.hidden) return;
  sheet.hidden = true;
  document.body.style.overflow = '';
  $('#sheet-body').innerHTML = '';
  if (typeof sheetCleanup === 'function') sheetCleanup();
  sheetCleanup = null;
}
$('#sheet').addEventListener('click', (e) => {
  if (e.target.closest('[data-close-sheet]')) closeSheet();
});
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeSheet(); });

function busy(btn, on, label) {
  if (!btn) return;
  if (on) { btn.dataset.label = btn.innerHTML; btn.disabled = true; btn.textContent = label || 'Enregistrement…'; }
  else { btn.disabled = false; if (btn.dataset.label) btn.innerHTML = btn.dataset.label; }
}

function renderChrome() {
  const top = $('#topbar'), tabs = $('#tabs');
  top.hidden = false; tabs.hidden = false;
  const sw = $('#site-switch');
  if (isSecteur()) {
    sw.innerHTML = S.sites.map((s) => `<button type="button" data-site="${s.id}" aria-pressed="${s.id === S.site}">${esc(s.short_name)}</button>`).join('');
    sw.className = 'site-switch';
  } else {
    sw.className = '';
    sw.innerHTML = `<span class="site-label">${esc(siteShort(S.site))}</span>`;
  }
  renderTabs();
}
$('#site-switch').addEventListener('click', (e) => {
  const b = e.target.closest('[data-site]');
  if (!b) return;
  S.site = Number(b.dataset.site);
  S.draftIn = {}; S.draftInRef = '';
  lsSet('stock.site', S.site);
  renderChrome();
  refreshBadges();
  render();
});

function tabDefs() {
  const cartN = Object.keys(S.cart).length;
  if (role() === 'agent') {
    return [
      { h: '#/accueil', l: 'Accueil', i: ICON.home, m: ['accueil'] },
      { h: '#/demander', l: 'Demander', i: ICON.ask, m: ['demander'], b: cartN },
      { h: '#/scan', l: 'Scanner', i: ICON.scan, m: ['scan'], scan: true },
      { h: '#/fiches', l: 'Fiches', i: ICON.shield, m: ['fiches'] },
      { h: '#/compte', l: 'Compte', i: ICON.user, m: ['compte'] },
    ];
  }
  return [
    { h: '#/accueil', l: 'Accueil', i: ICON.home, m: ['accueil', 'demandes'], b: S.pending },
    { h: '#/stock', l: 'Stock', i: ICON.stock, m: ['stock'] },
    { h: '#/scan', l: 'Scanner', i: ICON.scan, m: ['scan'], scan: true },
    { h: '#/historique', l: 'Historique', i: ICON.history, m: ['historique'] },
    { h: '#/plus', l: 'Plus', i: ICON.more, m: ['plus', 'entree', 'inventaire', 'fiches', 'produits', 'produit', 'utilisateurs', 'commande', 'exports', 'etiquettes', 'compte', 'demander'], b: isSecteur() ? S.pendingUsers : 0 },
  ];
}
function renderTabs() {
  const cur = route()[0];
  $('#tabs').innerHTML = `<div class="tabs-inner">${tabDefs().map((t) => `
    <a class="tab ${t.scan ? 'scan' : ''}" href="${t.h}" ${t.m.includes(cur) ? 'aria-current="page"' : ''}>
      ${t.scan ? `<span class="scan-dot">${t.i}</span>` : t.i}
      <span>${t.l}</span>
      ${t.b ? `<span class="badge-n">${t.b}</span>` : ''}
    </a>`).join('')}</div>`;
}

// ---------------------------------------------------------------------
// Données
// ---------------------------------------------------------------------
async function loadCore() {
  const sb = S.sb;
  const [sites, prods, settings, profs] = await Promise.all([
    sb.from('sites').select('*').order('id'),
    sb.from('products').select('*, stocks(*), safety_sheets(id)').order('code'),
    sb.from('settings').select('*').maybeSingle(),
    sb.from('profiles').select('id, full_name, role, site_id, active'),
  ]);
  for (const r of [sites, prods, settings, profs]) if (r.error) throw r.error;
  S.sites = sites.data;
  S.settings = settings.data;
  S.profiles = Object.fromEntries(profs.data.map((p) => [p.id, p]));
  setProducts(prods.data);
}
function setProducts(rows) {
  S.products = rows.map((p) => ({
    ...p,
    stockBy: Object.fromEntries((p.stocks || []).map((s) => [s.site_id, s])),
    sheetCount: (p.safety_sheets || []).length,
  })).sort((a, b) => a.code.localeCompare(b.code));
  S.byCode = Object.fromEntries(S.products.map((p) => [p.code, p]));
  S.byId = Object.fromEntries(S.products.map((p) => [p.id, p]));
}
async function reloadProducts() {
  const { data, error } = await S.sb.from('products').select('*, stocks(*), safety_sheets(id)').order('code');
  if (error) throw error;
  setProducts(data);
}
function applyStock(productId, site, qty) {
  const p = S.byId[productId];
  if (!p) return;
  if (!p.stockBy[site]) p.stockBy[site] = { product_id: productId, site_id: site, quantity: 0, min_quantity: 0, safety_margin: 0, location: '' };
  p.stockBy[site].quantity = Number(qty);
}
async function refreshStocks() {
  const { data, error } = await S.sb.from('stocks').select('*');
  if (error) return;
  for (const s of data) {
    const p = S.byId[s.product_id];
    if (p) p.stockBy[s.site_id] = s;
  }
}

// Récupère toutes les lignes d'une requête (pages de 1 000)
async function fetchAll(build) {
  const out = [];
  for (let from = 0; from < 50000; from += 1000) {
    const { data, error } = await build().range(from, from + 999);
    if (error) throw error;
    out.push(...data);
    if (data.length < 1000) break;
  }
  return out;
}

async function refreshBadges() {
  if (!S.me || !isResp()) return;
  try {
    let q = S.sb.from('requests').select('id', { count: 'exact', head: true }).eq('status', 'en_attente');
    q = q.eq('site_id', S.site);
    const { count } = await q;
    S.pending = count || 0;
    if (isSecteur()) {
      const r = await S.sb.from('profiles').select('id', { count: 'exact', head: true }).eq('active', false);
      S.pendingUsers = r.count || 0;
    }
    renderTabs();
  } catch { /* hors ligne */ }
}

// ---------------------------------------------------------------------
// Routeur
// ---------------------------------------------------------------------
function route() {
  return decodeURIComponent(location.hash.replace(/^#\/?/, '')).split('/').filter(Boolean);
}
function go(h) { if (location.hash === h) render(); else location.hash = h; }

function stopCamera() {
  cancelAnimationFrame(S.scanRAF);
  if (S.stream) { S.stream.getTracks().forEach((t) => t.stop()); S.stream = null; }
}

async function render() {
  if (!S.me) return;
  stopCamera();
  closeSheet();
  const tok = ++S.tok;
  const [page, a, b] = route();
  renderTabs();
  window.scrollTo(0, 0);
  const pages = {
    accueil: renderHome,
    demander: renderAsk,
    scan: renderScan,
    p: (t) => renderProduct(a, t),
    fiches: renderSheets,
    compte: renderAccount,
    stock: renderStock,
    historique: renderHistory,
    plus: renderMore,
    demandes: renderRequests,
    entree: renderDelivery,
    inventaire: renderInventory,
    etiquettes: renderLabels,
    exports: renderExports,
    produits: renderProductsAdmin,
    produit: (t) => renderProductForm(a, b, t),
    utilisateurs: renderUsers,
    commande: renderOrder,
  };
  const respOnly = ['stock', 'historique', 'plus', 'demandes', 'entree', 'inventaire', 'etiquettes', 'exports'];
  const secteurOnly = ['produits', 'produit', 'utilisateurs', 'commande'];
  let fn = pages[page];
  if (!fn || (respOnly.includes(page) && !isResp()) || (secteurOnly.includes(page) && !isSecteur())) {
    if (page && page !== 'accueil') { location.replace('#/accueil'); return; }
    fn = renderHome;
  }
  try {
    await fn(tok);
  } catch (e) {
    if (tok !== S.tok) return;
    main.innerHTML = `<div class="empty"><strong>Impossible d'afficher cette page.</strong>${esc(errMsg(e))}<div style="margin-top:12px"><button class="btn" type="button" id="retry">Réessayer</button></div></div>`;
    $('#retry').onclick = () => render();
  }
}
const stale = (tok) => tok !== S.tok;
window.addEventListener('hashchange', render);

// ---------------------------------------------------------------------
// Petits composants
// ---------------------------------------------------------------------
const searchBox = (id, value, ph) => `<div class="search">${ICON.search}<input type="search" id="${id}" value="${esc(value)}" placeholder="${esc(ph)}" autocomplete="off" enterkeyhint="search"></div>`;
const famChips = (id, cur, extra = []) => `<div class="chips" id="${id}">${['Tout', ...extra, ...families()].map((f) => `<button type="button" class="chip-btn" data-fam="${esc(f)}" aria-pressed="${f === cur}">${esc(f)}</button>`).join('')}</div>`;
const backLink = (h, l) => `<a class="back" href="${h}">${ICON.back.replace('<svg', '<svg width="18" height="18"')}${esc(l)}</a>`;
const pill = (st) => `<span class="pill ${st}">${STATUS_LABEL[st]}</span>`;
const matches = (p, q) => {
  if (!q) return true;
  const s = (p.name + ' ' + p.code + ' ' + p.family + ' ' + p.packaging + ' ' + (p.adelya_ref || '')).toLowerCase()
    .normalize('NFD').replace(/[̀-ͯ]/g, '');
  return q.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').split(/\s+/).every((w) => s.includes(w));
};
function groupByFamily(list) {
  const order = families();
  const g = new Map();
  for (const p of list) { if (!g.has(p.family)) g.set(p.family, []); g.get(p.family).push(p); }
  return [...g.entries()].sort((a, b) => order.indexOf(a[0]) - order.indexOf(b[0]));
}
const kindLabel = { sortie: 'Sortie', entree: 'Entrée', inventaire: 'Inventaire' };
const kindSign = { sortie: '−', entree: '+', inventaire: '=' };
function movementItem(m, showProduct = true) {
  const p = S.byId[m.product_id];
  const d = Number(m.delta);
  const sub = [
    `${kindLabel[m.kind]}${m.kind === 'inventaire' ? ` (compté ${fmt(m.quantity)})` : ''}`,
    personName(m.user_id),
    dfTime.format(new Date(m.created_at)),
    m.reference ? `BL ${m.reference}` : '',
    m.note && m.note !== 'Demande' ? m.note : (m.request_id ? 'sur demande' : ''),
    isSecteur() && showProduct ? siteShort(m.site_id) : '',
  ].filter(Boolean).join(' · ');
  return `<${p ? `a href="#/p/${esc(p.code)}"` : 'div'} class="item">
    <span class="mv-icon ${m.kind}">${kindSign[m.kind]}</span>
    <span class="main-txt"><span class="title">${showProduct ? esc(p ? p.name : 'Produit supprimé') : kindLabel[m.kind]}</span><span class="sub">${esc(sub)}</span></span>
    <span class="qty"><span class="delta ${d < 0 ? 'neg' : d > 0 ? 'pos' : ''}">${d > 0 ? '+' : ''}${fmt(d)}</span><span class="sub small">reste ${fmt(m.stock_after)}</span></span>
  </${p ? 'a' : 'div'}>`;
}

// Sélecteur de quantité compact, lié à un objet {id: qty}
function bindMiniSteppers(root, store, onChange) {
  root.addEventListener('click', (e) => {
    const b = e.target.closest('[data-step]');
    if (!b) return;
    const wrap = b.closest('.mini-stepper');
    const id = wrap.dataset.id;
    const inp = wrap.querySelector('input');
    let v = parseNum(inp.value);
    if (!Number.isFinite(v)) v = 0;
    v = Math.max(0, round2(v + Number(b.dataset.step)));
    inp.value = v ? fmt(v) : '';
    if (v) store[id] = v; else delete store[id];
    wrap.classList.toggle('on', !!v);
    onChange && onChange();
  });
  root.addEventListener('change', (e) => {
    const inp = e.target.closest('.mini-stepper input');
    if (!inp) return;
    const wrap = inp.closest('.mini-stepper');
    const v = parseNum(inp.value);
    if (Number.isFinite(v) && v > 0) { store[wrap.dataset.id] = round2(v); inp.value = fmt(v); }
    else { delete store[wrap.dataset.id]; inp.value = ''; }
    wrap.classList.toggle('on', !!store[wrap.dataset.id]);
    onChange && onChange();
  });
}
const miniStepper = (id, v) => `<span class="mini-stepper ${v ? 'on' : ''}" data-id="${id}"><button type="button" data-step="-1" aria-label="Moins">−</button><input type="text" inputmode="decimal" value="${v ? fmt(v) : ''}" placeholder="0" aria-label="Quantité"><button type="button" data-step="1" aria-label="Plus">+</button></span>`;

function stepperField(id, value, label) {
  return `<div class="field"><label for="${id}">${esc(label)}</label>
    <div class="stepper" data-stepper="${id}"><button type="button" data-d="-1" aria-label="Moins">−</button><input type="text" inputmode="decimal" id="${id}" value="${fmt(value)}"><button type="button" data-d="1" aria-label="Plus">+</button></div></div>`;
}
function bindStepper(root, id, onChange) {
  const wrap = root.querySelector(`[data-stepper="${id}"]`);
  const inp = wrap.querySelector('input');
  wrap.addEventListener('click', (e) => {
    const b = e.target.closest('[data-d]');
    if (!b) return;
    let v = parseNum(inp.value);
    if (!Number.isFinite(v)) v = 0;
    v = Math.max(0, round2(v + Number(b.dataset.d)));
    inp.value = fmt(v);
    onChange && onChange();
  });
  inp.addEventListener('input', () => onChange && onChange());
  inp.addEventListener('focus', () => inp.select());
  return () => parseNum(inp.value);
}

function download(filename, text, type = 'text/csv;charset=utf-8') {
  const blob = new Blob([text], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}
function toCSV(rows) {
  const cell = (v) => {
    if (typeof v === 'number') return String(v).replace('.', ',');
    const s = String(v ?? '');
    return /[;"\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return '﻿' + rows.map((r) => r.map(cell).join(';')).join('\r\n');
}

// ---------------------------------------------------------------------
// ACCUEIL
// ---------------------------------------------------------------------
async function renderHome(tok) {
  if (role() === 'agent') return renderHomeAgent(tok);
  const site = S.site;
  const since = new Date(); since.setHours(0, 0, 0, 0);
  const [reqs, mvs] = await Promise.all([
    S.sb.from('requests').select('*, request_items(*)').eq('site_id', site).eq('status', 'en_attente').order('created_at'),
    S.sb.from('movements').select('*').eq('site_id', site).order('created_at', { ascending: false }).limit(6),
  ]);
  if (reqs.error) throw reqs.error;
  if (mvs.error) throw mvs.error;
  if (stale(tok)) return;
  await refreshStocks();
  if (stale(tok)) return;
  S.pending = reqs.data.length;
  renderTabs();
  const alerts = activeProducts().filter((p) => isAlert(p, site));
  const todayCount = mvs.data.filter((m) => new Date(m.created_at) >= since).length;
  const pendingUsers = isSecteur() ? Object.values(S.profiles).filter((p) => !p.active).length : 0;

  main.innerHTML = `
    <div class="page-head">
      <span class="eyebrow">${esc(cap(dfDay.format(new Date())))}</span>
      <h1>${esc(siteName(site))}</h1>
    </div>
    ${pendingUsers ? `<a class="notice info" href="#/utilisateurs" style="text-decoration:none">${ICON.users.replace('<svg', '<svg width="22" height="22"')}<span>${pendingUsers} compte${pendingUsers > 1 ? 's' : ''} en attente de validation</span></a>` : ''}
    <div class="kpis">
      <a class="kpi ${S.pending ? 'attn' : ''}" href="#/demandes"><span class="n">${S.pending}</span><span class="l">demande${S.pending > 1 ? 's' : ''} en attente</span></a>
      <a class="kpi ${alerts.length ? 'alert' : ''}" href="#/stock/alertes"><span class="n">${alerts.length}</span><span class="l">produit${alerts.length > 1 ? 's' : ''} sous le seuil</span></a>
      <a class="kpi" href="#/historique"><span class="n">${todayCount}${todayCount === 6 ? '+' : ''}</span><span class="l">mouvement${todayCount > 1 ? 's' : ''} aujourd'hui</span></a>
    </div>
    ${canManage(site) ? `
    <div class="big-actions">
      <button type="button" class="big-action primary" id="act-out">${ICON.out}<span>Sortie<small>Remettre un produit</small></span></button>
      <a class="big-action" href="#/entree">${ICON.in}<span>Entrée<small>Livraison Adelya</small></span></a>
      <a class="big-action wide" href="#/inventaire">${ICON.count}<span>Inventaire<small>Compter le stock réel</small></span></a>
    </div>` : ''}
    <section class="section">
      <div class="section-head"><h2>Demandes en attente</h2>${reqs.data.length ? '<a href="#/demandes" class="small">Tout voir</a>' : ''}</div>
      ${reqs.data.length ? `<div class="list">${reqs.data.slice(0, 5).map(requestItem).join('')}</div>` : '<div class="empty">Aucune demande en attente.</div>'}
    </section>
    <section class="section">
      <div class="section-head"><h2>À surveiller</h2>${alerts.length ? '<a href="#/stock/alertes" class="small">Tout voir</a>' : ''}</div>
      ${alerts.length ? `<div class="list">${alerts.slice(0, 6).map((p) => productRow(p, site)).join('')}</div>`
        : '<div class="empty">Aucun produit sous son seuil d\'alerte.<br><span class="small">Les seuils se règlent sur la fiche de chaque produit.</span></div>'}
    </section>
    <section class="section">
      <div class="section-head"><h2>Derniers mouvements</h2><a href="#/historique" class="small">Historique</a></div>
      ${mvs.data.length ? `<div class="list">${mvs.data.map((m) => movementItem(m)).join('')}</div>` : '<div class="empty"><strong>Aucun mouvement pour l\'instant.</strong>Commencez par un inventaire de départ pour enregistrer le stock réel.</div>'}
    </section>`;
  const out = $('#act-out');
  if (out) out.onclick = () => pickProduct('Sortie : quel produit ?', (p) => openMovement(p, 'sortie'));
  bindRequestButtons(reqs.data);
}

function requestItem(r) {
  const items = r.request_items || [];
  const summary = items.map((it) => `${fmt(it.quantity)} × ${S.byId[it.product_id]?.name || 'Produit'}`).join(', ');
  return `<button type="button" class="item" data-req="${r.id}">
    <span class="mv-icon sortie">${items.length}</span>
    <span class="main-txt"><span class="title">${esc(personName(r.requested_by))}</span><span class="sub">${esc(summary)}</span>
    ${r.note ? `<span class="sub">« ${esc(r.note)} »</span>` : ''}</span>
    <span class="qty"><span class="sub small">${esc(dfTime.format(new Date(r.created_at)))}</span><span class="pill warn">Traiter</span></span>
  </button>`;
}
function bindRequestButtons(list) {
  $$('[data-req]', main).forEach((b) => {
    b.onclick = () => openRequest(list.find((r) => r.id === b.dataset.req));
  });
}

function openRequest(r) {
  if (!r) return;
  const given = {};
  const lines = (r.request_items || []).map((it) => {
    const p = S.byId[it.product_id];
    const st = p ? Number(stockOf(p, r.site_id).quantity) : 0;
    given[it.id] = Math.min(Number(it.quantity), st);
    return { it, p, st };
  });
  openSheet(`
    <h2 id="sheet-title">Demande de ${esc(personName(r.requested_by))}</h2>
    <p class="muted small">${esc(dfTime.format(new Date(r.created_at)))} · ${esc(siteName(r.site_id))}</p>
    ${r.note ? `<p>« ${esc(r.note)} »</p>` : ''}
    <div class="list">${lines.map(({ it, p, st }) => `
      <div class="item">
        <span class="main-txt"><span class="title">${esc(p ? p.name : 'Produit')}</span>
        <span class="sub">${esc(p?.packaging || '')} · demandé ${fmt(it.quantity)} · en stock ${fmt(st)}</span>
        ${st < Number(it.quantity) ? '<span class="sub" style="color:var(--warn);font-weight:700">Stock insuffisant pour tout remettre</span>' : ''}</span>
        ${miniStepper(it.id, given[it.id])}
      </div>`).join('')}</div>
    <p class="small muted">Ajustez si vous remettez moins que demandé. Une ligne à 0 n'est pas remise.</p>
    <button type="button" class="btn primary block" id="rq-ok">Remettre et valider</button>
    <div class="stack" id="rq-refuse-box" hidden>
      <div class="field"><label for="rq-reason">Motif du refus</label><input type="text" id="rq-reason" placeholder="Ex. : produit en rupture, déjà fourni hier"></div>
      <button type="button" class="btn danger block" id="rq-refuse-go">Confirmer le refus</button>
    </div>
    <button type="button" class="btn ghost block" id="rq-refuse">Refuser la demande</button>`,
  (root) => {
    bindMiniSteppers(root, given);
    $('#rq-refuse', root).onclick = (e) => { $('#rq-refuse-box', root).hidden = false; e.target.hidden = true; $('#rq-reason', root).focus(); };
    $('#rq-refuse-go', root).onclick = async (e) => {
      busy(e.target, true);
      const { error } = await S.sb.rpc('refuse_request', { p_request: r.id, p_reason: $('#rq-reason', root).value.trim() });
      busy(e.target, false);
      if (error) return toast(errMsg(error), true);
      closeSheet(); toast('Demande refusée'); refreshBadges(); render();
    };
    $('#rq-ok', root).onclick = async (e) => {
      const payload = (r.request_items || []).map((it) => ({ item_id: it.id, given: given[it.id] || 0 }));
      if (!payload.some((x) => x.given > 0)) return toast('Rien à remettre : refusez plutôt la demande.', true);
      busy(e.target, true);
      const { error } = await S.sb.rpc('validate_request', { p_request: r.id, p_given: payload });
      busy(e.target, false);
      if (error) return toast(errMsg(error), true);
      closeSheet(); toast('Demande validée, stock mis à jour'); refreshBadges(); render();
    };
  });
}

async function renderHomeAgent(tok) {
  const { data, error } = await S.sb.from('requests').select('*, request_items(*)')
    .eq('requested_by', S.me.id).order('created_at', { ascending: false }).limit(15);
  if (error) throw error;
  if (stale(tok)) return;
  const stLabel = { en_attente: ['warn', 'En attente'], validee: ['ok', 'Remise'], refusee: ['danger', 'Refusée'], annulee: ['', 'Annulée'] };
  main.innerHTML = `
    <div class="page-head">
      <span class="eyebrow">${esc(cap(dfDay.format(new Date())))} · ${esc(siteShort(S.site))}</span>
      <h1>Bonjour ${esc(firstName(S.me.full_name))}</h1>
    </div>
    <div class="big-actions">
      <a class="big-action primary wide" href="#/demander">${ICON.ask}<span>Faire une demande<small>Choisir les produits dont j'ai besoin</small></span></a>
      <a class="big-action" href="#/scan">${ICON.scan}<span>Scanner<small>Un QR code d'étagère</small></span></a>
      <a class="big-action" href="#/fiches">${ICON.shield}<span>Sécurité<small>Fiches des produits</small></span></a>
    </div>
    <section class="section">
      <h2>Mes demandes</h2>
      ${data.length ? `<div class="list">${data.map((r) => {
        const [cls, lab] = stLabel[r.status];
        const items = (r.request_items || []).map((it) => `${fmt(it.given ?? it.quantity)}${it.given != null && Number(it.given) !== Number(it.quantity) ? ` (sur ${fmt(it.quantity)})` : ''} × ${S.byId[it.product_id]?.name || 'Produit'}`).join(', ');
        return `<div class="item"><span class="main-txt">
            <span class="title">${esc(items)}</span>
            <span class="sub">${esc(dfTime.format(new Date(r.created_at)))}${r.note ? ' · « ' + esc(r.note) + ' »' : ''}</span>
            ${r.status === 'refusee' && r.refuse_reason ? `<span class="sub" style="color:var(--danger)">Motif : ${esc(r.refuse_reason)}</span>` : ''}
          </span><span class="qty"><span class="pill ${cls}">${lab}</span>
          ${r.status === 'en_attente' ? `<button type="button" class="btn small ghost" data-cancel="${r.id}">Annuler</button>` : ''}</span></div>`;
      }).join('')}</div>` : '<div class="empty"><strong>Aucune demande pour l\'instant.</strong>Touchez « Faire une demande » pour commencer.</div>'}
    </section>`;
  $$('[data-cancel]', main).forEach((b) => {
    b.onclick = async () => {
      busy(b, true, '…');
      const { error: e } = await S.sb.rpc('cancel_request', { p_request: b.dataset.cancel });
      if (e) { busy(b, false); return toast(errMsg(e), true); }
      toast('Demande annulée'); render();
    };
  });
}

// ---------------------------------------------------------------------
// DEMANDER (catalogue + panier)
// ---------------------------------------------------------------------
function saveCart() { lsSet('stock.cart', S.cart); }

async function renderAsk() {
  const f = S.filters;
  main.innerHTML = `
    <div class="page-head"><h1>Faire une demande</h1><p class="muted">Choisissez les produits et les quantités, puis envoyez. Le responsable de l'installation est prévenu.</p></div>
    ${searchBox('ask-q', f.askQ, 'Rechercher un produit')}
    ${famChips('ask-fam', f.askFam)}
    <div id="ask-list"></div>
    <div class="cartbar" id="cartbar" hidden><button type="button" class="btn signal" id="cart-send"></button></div>`;
  const draw = () => {
    const list = activeProducts().filter((p) => (f.askFam === 'Tout' || p.family === f.askFam) && matches(p, f.askQ));
    $('#ask-list').innerHTML = list.length ? `<div class="list">${groupByFamily(list).map(([fam, ps]) => `
      <div class="group-label">${esc(fam)}</div>
      ${ps.map((p) => {
        const st = stockOf(p);
        return `<div class="item"><a class="main-txt" href="#/p/${esc(p.code)}" style="text-decoration:none;color:inherit">
          <span class="title">${esc(p.name)}</span>
          <span class="sub">${esc(p.packaging)} · ${Number(st.quantity) > 0 ? `en stock : ${fmt(st.quantity)}` : '<span style="color:var(--danger)">épuisé</span>'}</span></a>
          ${miniStepper(p.id, S.cart[p.id])}</div>`;
      }).join('')}`).join('')}</div>` : '<div class="empty">Aucun produit ne correspond.</div>';
  };
  const drawCart = () => {
    const n = Object.keys(S.cart).length;
    $('#cartbar').hidden = !n;
    $('#cart-send').textContent = `Envoyer la demande · ${n} produit${n > 1 ? 's' : ''}`;
    renderTabs();
  };
  draw(); drawCart();
  bindMiniSteppers($('#ask-list'), S.cart, () => { saveCart(); drawCart(); });
  $('#ask-q').oninput = (e) => { f.askQ = e.target.value; draw(); };
  $('#ask-fam').onclick = (e) => {
    const b = e.target.closest('[data-fam]');
    if (!b) return;
    f.askFam = b.dataset.fam;
    $$('#ask-fam .chip-btn').forEach((x) => x.setAttribute('aria-pressed', x === b));
    draw();
  };
  $('#cart-send').onclick = openCartSheet;
}

function openCartSheet() {
  const ids = Object.keys(S.cart).filter((id) => S.byId[id]);
  if (!ids.length) return;
  openSheet(`
    <h2 id="sheet-title">Ma demande</h2>
    <div class="list">${ids.map((id) => `<div class="item"><span class="main-txt"><span class="title">${esc(S.byId[id].name)}</span><span class="sub">${esc(S.byId[id].packaging)}</span></span><span class="qty"><span class="n">${fmt(S.cart[id])}</span></span></div>`).join('')}</div>
    <div class="field"><label for="cart-note">Pour quel endroit ? (facultatif)</label><input type="text" id="cart-note" placeholder="Ex. : vestiaires 3 et 4, gradins"></div>
    <button type="button" class="btn primary block" id="cart-go">Envoyer au responsable</button>
    <button type="button" class="btn ghost block" data-close-sheet>Modifier</button>`,
  (root) => {
    $('#cart-go', root).onclick = async (e) => {
      busy(e.target, true, 'Envoi…');
      const items = ids.map((id) => ({ product_id: id, quantity: S.cart[id] }));
      const { error } = await S.sb.rpc('create_request', { p_items: items, p_note: $('#cart-note', root).value.trim() });
      busy(e.target, false);
      if (error) return toast(errMsg(error), true);
      S.cart = {}; saveCart();
      closeSheet(); toast('Demande envoyée');
      go('#/accueil');
    };
  });
}

// ---------------------------------------------------------------------
// SCANNER
// ---------------------------------------------------------------------
function codeFromText(t) {
  const s = String(t || '').trim();
  let m = s.match(/#\/p\/([A-Za-z0-9-]+)/);
  if (m) return m[1].toUpperCase();
  m = s.match(/^(?:STOCK:)?([A-Za-z0-9-]{2,20})$/i);
  return m ? m[1].toUpperCase() : null;
}
function openScanned(text) {
  const code = codeFromText(text);
  if (code && S.byCode[code]) { if (navigator.vibrate) navigator.vibrate(60); go(`#/p/${code}`); return true; }
  toast('QR code non reconnu : ce n\'est pas une étiquette de produit.', true);
  return false;
}

async function renderScan(tok) {
  main.innerHTML = `
    <div class="page-head"><h1>Scanner</h1><p class="muted">Visez l'étiquette QR collée sur l'étagère.</p></div>
    <div class="scanner" id="scanner"><video id="scan-video" playsinline muted></video><div class="frame"></div><div class="hint">Recherche d'un QR code…</div></div>
    <div class="notice" id="scan-fallback" hidden></div>
    <div class="grid-2">
      <label class="btn" for="scan-photo">${ICON.camera}Prendre une photo</label>
      <button type="button" class="btn" id="scan-manual">Saisir le code</button>
    </div>
    <input type="file" id="scan-photo" accept="image/*" capture="environment" hidden>
    <p class="small muted">Astuce : l'appareil photo du téléphone lit aussi les étiquettes et ouvre directement la fiche du produit.</p>`;
  $('#scan-photo').onchange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const text = await decodeImageFile(file);
    if (text) openScanned(text); else toast('Aucun QR code lisible sur la photo. Rapprochez-vous et réessayez.', true);
    e.target.value = '';
  };
  $('#scan-manual').onclick = () => pickProduct('Choisir un produit', (p) => go(`#/p/${p.code}`));

  const video = $('#scan-video');
  const fail = (msg) => {
    if (stale(tok)) return;
    $('#scanner').hidden = true;
    const fb = $('#scan-fallback');
    fb.hidden = false;
    fb.textContent = msg;
  };
  if (!navigator.mediaDevices?.getUserMedia) return fail('La caméra en direct n\'est pas disponible sur ce navigateur. Utilisez « Prendre une photo ».');
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 } }, audio: false });
    if (stale(tok)) { stream.getTracks().forEach((t) => t.stop()); return; }
    S.stream = stream;
    video.srcObject = stream;
    await video.play();
  } catch {
    return fail('Accès à la caméra refusé. Autorisez la caméra pour ce site dans les réglages du navigateur, ou utilisez « Prendre une photo ».');
  }
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  let last = 0;
  const loop = (t) => {
    if (stale(tok) || !S.stream) return;
    S.scanRAF = requestAnimationFrame(loop);
    if (t - last < 180 || video.readyState < 2) return;
    last = t;
    const w = 480, h = Math.round((video.videoHeight / video.videoWidth) * w) || 640;
    canvas.width = w; canvas.height = h;
    ctx.drawImage(video, 0, 0, w, h);
    const img = ctx.getImageData(0, 0, w, h);
    const res = window.jsQR && window.jsQR(img.data, w, h, { inversionAttempts: 'dontInvert' });
    if (res && res.data) {
      const code = codeFromText(res.data);
      if (code && S.byCode[code]) { stopCamera(); openScanned(res.data); }
    }
  };
  S.scanRAF = requestAnimationFrame(loop);
}

async function loadImage(file) {
  if (window.createImageBitmap) {
    try { return await createImageBitmap(file); } catch { /* repli */ }
  }
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => { resolve(img); setTimeout(() => URL.revokeObjectURL(url), 1000); };
    img.onerror = reject;
    img.src = url;
  });
}
async function decodeImageFile(file) {
  try {
    const img = await loadImage(file);
    const W = img.width, H = img.height;
    for (const max of [1000, 1600, 700]) {
      const k = Math.min(1, max / Math.max(W, H));
      const w = Math.round(W * k), h = Math.round(H * k);
      const c = document.createElement('canvas');
      c.width = w; c.height = h;
      const ctx = c.getContext('2d');
      ctx.drawImage(img, 0, 0, w, h);
      const r = window.jsQR(ctx.getImageData(0, 0, w, h).data, w, h, { inversionAttempts: 'attemptBoth' });
      if (r && r.data) return r.data;
    }
  } catch { /* image illisible */ }
  return null;
}

// Feuille de choix d'un produit (recherche)
function pickProduct(title, onPick) {
  openSheet(`
    <h2 id="sheet-title">${esc(title)}</h2>
    ${searchBox('pick-q', '', 'Nom, code ou famille')}
    <div id="pick-list" class="list"></div>`,
  (root) => {
    const q = $('#pick-q', root);
    const draw = () => {
      const list = activeProducts().filter((p) => matches(p, q.value)).slice(0, 60);
      $('#pick-list', root).innerHTML = list.map((p) => `<button type="button" class="item" data-pick="${p.id}">
        <span class="main-txt"><span class="title">${esc(p.name)}</span><span class="sub">${esc(p.code)} · ${esc(p.packaging)}</span></span>
        <span class="qty"><span class="n">${fmt(stockOf(p).quantity)}</span></span></button>`).join('') || '<div class="empty">Aucun produit.</div>';
    };
    draw();
    q.oninput = draw;
    $('#pick-list', root).onclick = (e) => {
      const b = e.target.closest('[data-pick]');
      if (!b) return;
      const p = S.byId[b.dataset.pick];
      closeSheet();
      onPick(p);
    };
    setTimeout(() => q.focus(), 80);
  });
}

// ---------------------------------------------------------------------
// FICHE PRODUIT
// ---------------------------------------------------------------------
async function renderProduct(code, tok) {
  const p = S.byCode[String(code || '').toUpperCase()];
  if (!p) {
    main.innerHTML = `${backLink('#/accueil', 'Accueil')}<div class="empty"><strong>Produit introuvable.</strong>Ce code ne correspond à aucun produit de la liste.</div>`;
    return;
  }
  const sites = isSecteur() ? S.sites.map((s) => s.id) : [S.site];
  const since = new Date(Date.now() - 90 * DAY).toISOString();
  const [sheets, mv] = await Promise.all([
    S.sb.from('safety_sheets').select('*').eq('product_id', p.id).order('page'),
    S.sb.from('movements').select('*').eq('product_id', p.id).in('site_id', sites).order('created_at', { ascending: false }).limit(200),
  ]);
  if (sheets.error) throw sheets.error;
  if (mv.error) throw mv.error;
  await refreshStocks();
  if (stale(tok)) return;
  let urls = {};
  if (sheets.data.length) {
    const { data } = await S.sb.storage.from('fiches-securite').createSignedUrls(sheets.data.map((s) => s.file_path), 3600);
    (data || []).forEach((d) => { if (d.signedUrl) urls[d.path] = d.signedUrl; });
  }
  const site = S.site;
  const st = stockOf(p, site);
  const stt = status(st);
  const outs90 = mv.data.filter((m) => m.site_id === site && m.kind === 'sortie' && new Date(m.created_at) >= new Date(since));
  const firstMv = mv.data.filter((m) => m.site_id === site).at(-1);
  const days = firstMv ? Math.max(14, Math.min(90, (Date.now() - new Date(firstMv.created_at)) / DAY)) : 0;
  const monthly = days ? outs90.reduce((a, m) => a + Number(m.quantity), 0) / days * 30.44 : 0;
  const q = Number(st.quantity), mn = Number(st.min_quantity);
  const pct = Math.max(4, Math.min(100, (q / Math.max(mn * 2, q, 1)) * 100));
  const hasSafety = p.chemical || p.signal_word || (p.pictograms || []).length || (p.ppe || []).length || p.hazards || p.first_aid || p.incompat || p.storage || sheets.data.length;
  const other = isSecteur() ? S.sites.filter((s) => s.id !== site) : [];

  main.innerHTML = `
    ${backLink(role() === 'agent' ? '#/demander' : '#/stock', role() === 'agent' ? 'Catalogue' : 'Stock')}
    <div class="page-head">
      <span class="eyebrow">${esc(p.family)} · <span class="mono">${esc(p.code)}</span></span>
      <h1>${esc(p.name)}</h1>
      <p class="muted">${esc(p.packaging)}${p.bpu_line ? ` · BPU ligne ${p.bpu_line}` : ''}${p.adelya_ref ? ` · réf. Adelya ${esc(p.adelya_ref)}` : ''}${!p.active ? ' · <strong>archivé</strong>' : ''}</p>
    </div>

    <div class="card stack">
      <div class="row" style="justify-content:space-between"><span class="eyebrow">Stock ${esc(siteShort(site))}</span>${pill(stt)}</div>
      <div class="stock-hero">
        <div><div class="big">${fmt(q)}</div><div class="unit">${esc(p.packaging)}</div></div>
        <div class="meter ${stt}"><span style="width:${pct}%"></span></div>
      </div>
      <div class="facts">
        <div class="fact"><div class="v">${mn ? fmt(mn) : '—'}</div><div class="k">Seuil d'alerte</div></div>
        <div class="fact"><div class="v">${monthly ? fmt(round2(monthly)) : '—'}</div><div class="k">Sorties par mois</div></div>
        <div class="fact"><div class="v" style="font-size:16px">${esc(st.location || '—')}</div><div class="k">Emplacement</div></div>
      </div>
      ${other.map((s) => `<p class="small muted">${esc(s.short_name)} : <strong class="num">${fmt(stockOf(p, s.id).quantity)}</strong> en stock</p>`).join('')}
      ${canManage(site) ? `
      <div class="grid-3">
        <button type="button" class="btn signal" data-mv="sortie">Sortie</button>
        <button type="button" class="btn" data-mv="entree">Entrée</button>
        <button type="button" class="btn" data-mv="inventaire">Compter</button>
      </div>
      <button type="button" class="btn ghost small" id="st-settings">Régler le seuil et l'emplacement</button>` : ''}
      ${role() === 'agent' && p.active ? `<button type="button" class="btn primary block" id="add-cart">${ICON.ask}Ajouter à ma demande</button>` : ''}
    </div>

    ${hasSafety ? `
    <section class="section">
      <h2>Sécurité</h2>
      <div class="card stack">
        ${p.signal_word ? `<div class="signal-band ${p.signal_word === 'Danger' ? 'danger' : 'attention'}">${esc(p.signal_word)}</div>` : ''}
        ${(p.pictograms || []).length ? `<div class="pictos">${p.pictograms.map((c) => `<div class="picto">${picto(c)}<span>${esc(PICTOS[c]?.label || c)}</span></div>`).join('')}</div>` : ''}
        ${(p.ppe || []).length ? `<div class="safety-block"><h3>Protections à porter</h3><div class="ppe">${p.ppe.map((x) => `<span>${esc(x)}</span>`).join('')}</div></div>` : ''}
        ${p.hazards ? `<div class="safety-block"><h3>Dangers</h3><p>${esc(p.hazards)}</p></div>` : ''}
        ${p.incompat ? `<div class="safety-block"><h3>Ne jamais mélanger avec</h3><p>${esc(p.incompat)}</p></div>` : ''}
        ${p.first_aid ? `<div class="safety-block"><h3>Premiers secours</h3><p>${esc(p.first_aid)}</p></div>` : ''}
        ${p.storage ? `<div class="safety-block"><h3>Stockage</h3><p>${esc(p.storage)}</p></div>` : ''}
        <div class="safety-block"><h3>Fiche de données de sécurité</h3></div>
        ${sheets.data.length ? `<div class="pages">${sheets.data.map((s, i) => {
          const url = urls[s.file_path];
          const isPdf = /\.pdf$/i.test(s.file_path);
          return `<div class="page-thumb">
            <a href="${esc(url || '#')}" target="_blank" rel="noopener" style="display:contents">${isPdf ? `${ICON.file.replace('<svg', '<svg width="34" height="34"')}` : `<img src="${esc(url || '')}" alt="Page ${i + 1} de la fiche" loading="lazy">`}</a>
            <span class="badge">${isPdf ? 'PDF' : `Page ${i + 1}`}</span>
            ${isSecteur() ? `<button type="button" class="del" data-del-sheet="${s.id}" aria-label="Supprimer cette page">×</button>` : ''}
          </div>`;
        }).join('')}</div>` : `<div class="notice">${p.chemical ? 'Fiche de sécurité pas encore ajoutée. Consultez l\'étiquette du produit en attendant.' : 'Aucune fiche ajoutée.'}</div>`}
        ${isSecteur() ? `
        <div class="grid-2">
          <label class="btn" for="fds-cam">${ICON.camera}Photographier</label>
          <label class="btn" for="fds-file">${ICON.file}PDF ou image</label>
        </div>
        <input type="file" id="fds-cam" accept="image/*" capture="environment" hidden>
        <input type="file" id="fds-file" accept="image/*,application/pdf" multiple hidden>
        <a class="btn ghost small" href="#/produit/${p.id}/modifier">Modifier les consignes de sécurité</a>` : ''}
      </div>
    </section>` : (isSecteur() ? `<a class="btn ghost" href="#/produit/${p.id}/modifier">Ajouter des consignes de sécurité</a>` : '')}

    ${isResp() ? `
    <section class="section">
      <h2>Derniers mouvements</h2>
      ${mv.data.length ? `<div class="list">${mv.data.slice(0, 15).map((m) => movementItem(m, false)).join('')}</div>` : '<div class="empty">Aucun mouvement pour ce produit.</div>'}
    </section>` : ''}
    ${isSecteur() ? `<a class="btn ghost" href="#/produit/${p.id}/modifier">Modifier le produit</a>` : ''}`;

  $$('[data-mv]', main).forEach((b) => { b.onclick = () => openMovement(p, b.dataset.mv); });
  const sset = $('#st-settings');
  if (sset) sset.onclick = () => openStockSettings(p);
  const add = $('#add-cart');
  if (add) add.onclick = () => openAddToCart(p);
  const cam = $('#fds-cam'), file = $('#fds-file');
  if (cam) cam.onchange = (e) => uploadSheets(p, e.target.files);
  if (file) file.onchange = (e) => uploadSheets(p, e.target.files);
  $$('[data-del-sheet]', main).forEach((b) => {
    b.onclick = () => confirmSheet('Supprimer cette page de la fiche ?', 'Supprimer', async () => {
      const s = sheets.data.find((x) => x.id === b.dataset.delSheet);
      await S.sb.storage.from('fiches-securite').remove([s.file_path]);
      const { error } = await S.sb.from('safety_sheets').delete().eq('id', s.id);
      if (error) throw error;
      p.sheetCount = Math.max(0, p.sheetCount - 1);
      toast('Page supprimée');
      render();
    });
  });
}

function confirmSheet(question, okLabel, action) {
  openSheet(`<h2 id="sheet-title">${esc(question)}</h2>
    <button type="button" class="btn danger block" id="cf-ok">${esc(okLabel)}</button>
    <button type="button" class="btn ghost block" data-close-sheet>Annuler</button>`,
  (root) => {
    $('#cf-ok', root).onclick = async (e) => {
      busy(e.target, true);
      try { await action(); closeSheet(); } catch (err) { busy(e.target, false); toast(errMsg(err), true); }
    };
  });
}

async function compressImage(file) {
  if (!/^image\//.test(file.type) || /gif|svg/.test(file.type)) return file;
  try {
    const img = await loadImage(file);
    const k = Math.min(1, 1800 / Math.max(img.width, img.height));
    const c = document.createElement('canvas');
    c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
    c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
    const blob = await new Promise((r) => c.toBlob(r, 'image/jpeg', 0.82));
    return blob || file;
  } catch { return file; }
}
async function uploadSheets(p, files) {
  const list = Array.from(files || []);
  if (!list.length) return;
  toast(`Envoi de ${list.length} fichier${list.length > 1 ? 's' : ''}…`);
  const { data: existing } = await S.sb.from('safety_sheets').select('page').eq('product_id', p.id);
  let page = Math.max(0, ...(existing || []).map((x) => x.page));
  try {
    for (const f of list) {
      const isPdf = f.type === 'application/pdf' || /\.pdf$/i.test(f.name);
      if (isPdf && f.size > 15 * 1024 * 1024) throw new Error('PDF trop lourd (15 Mo maximum).');
      const body = isPdf ? f : await compressImage(f);
      const path = `${p.id}/${Date.now()}-${Math.random().toString(36).slice(2, 7)}.${isPdf ? 'pdf' : 'jpg'}`;
      const up = await S.sb.storage.from('fiches-securite').upload(path, body, { contentType: isPdf ? 'application/pdf' : 'image/jpeg', upsert: false });
      if (up.error) throw up.error;
      page += 1;
      const ins = await S.sb.from('safety_sheets').insert({ product_id: p.id, file_path: path, file_name: f.name || '', page, uploaded_by: S.me.id });
      if (ins.error) throw ins.error;
      p.sheetCount += 1;
    }
    toast('Fiche de sécurité ajoutée');
  } catch (e) {
    toast(errMsg(e), true);
  }
  render();
}

function openAddToCart(p) {
  let getQty;
  openSheet(`<h2 id="sheet-title">${esc(p.name)}</h2><p class="muted">${esc(p.packaging)} · en stock : ${fmt(stockOf(p).quantity)}</p>
    ${stepperField('add-q', S.cart[p.id] || 1, 'Quantité demandée')}
    <button type="button" class="btn primary block" id="add-go">Ajouter à ma demande</button>`,
  (root) => {
    getQty = bindStepper(root, 'add-q');
    $('#add-go', root).onclick = () => {
      const v = getQty();
      if (!(v > 0)) return toast('Indiquez une quantité.', true);
      S.cart[p.id] = round2(v); saveCart();
      closeSheet(); toast('Ajouté à votre demande'); renderTabs();
      go('#/demander');
    };
  });
}

function openMovement(p, kind) {
  const site = S.site;
  let k = kind;
  const st = () => Number(stockOf(p, site).quantity);
  openSheet(`
    <h2 id="sheet-title">${esc(p.name)}</h2>
    <p class="muted small">${esc(p.packaging)} · ${esc(siteName(site))}</p>
    <div class="seg" id="mv-kind">
      <button type="button" data-kind="sortie">Sortie</button>
      <button type="button" data-kind="entree">Entrée</button>
      <button type="button" data-kind="inventaire">Inventaire</button>
    </div>
    <div id="mv-q-wrap"></div>
    <div class="notice info" id="mv-preview"></div>
    <div class="field" id="mv-ref-wrap"><label for="mv-ref">N° de bon de livraison (facultatif)</label><input type="text" id="mv-ref" autocomplete="off"></div>
    <div class="field"><label for="mv-note" id="mv-note-l">Note (facultatif)</label><input type="text" id="mv-note" autocomplete="off"></div>
    <button type="button" class="btn primary block" id="mv-go">Enregistrer</button>`,
  (root) => {
    let getQty = () => 0;
    const preview = () => {
      const v = getQty();
      const b = st();
      const after = k === 'entree' ? b + (v || 0) : k === 'sortie' ? b - (v || 0) : (v || 0);
      const el = $('#mv-preview', root);
      if (k === 'sortie' && after < 0) { el.className = 'notice danger'; el.textContent = `Stock insuffisant : il reste ${fmt(b)}.`; }
      else { el.className = 'notice info'; el.innerHTML = `Stock : <strong class="num">${fmt(b)}</strong> → <strong class="num">${fmt(round2(after))}</strong>${k === 'inventaire' ? ` (écart ${after - b > 0 ? '+' : ''}${fmt(round2(after - b))})` : ''}`; }
    };
    const setKind = (nk) => {
      k = nk;
      $$('#mv-kind button', root).forEach((b) => b.setAttribute('aria-pressed', b.dataset.kind === k));
      $('#mv-q-wrap', root).innerHTML = stepperField('mv-q', k === 'inventaire' ? st() : 1, k === 'inventaire' ? 'Quantité comptée en réserve' : 'Quantité');
      getQty = bindStepper(root, 'mv-q', preview);
      $('#mv-ref-wrap', root).hidden = k !== 'entree';
      $('#mv-note-l', root).textContent = k === 'sortie' ? 'Pour qui ou pour quel endroit ? (facultatif)' : 'Note (facultatif)';
      $('#mv-go', root).textContent = { sortie: 'Enregistrer la sortie', entree: 'Enregistrer l\'entrée', inventaire: 'Enregistrer le comptage' }[k];
      preview();
    };
    $('#mv-kind', root).onclick = (e) => { const b = e.target.closest('[data-kind]'); if (b) setKind(b.dataset.kind); };
    setKind(k);
    $('#mv-go', root).onclick = async (e) => {
      const v = getQty();
      if (!Number.isFinite(v) || v < 0 || (k !== 'inventaire' && v === 0)) return toast('Indiquez une quantité valide.', true);
      busy(e.target, true);
      const { data, error } = await S.sb.rpc('record_movement', {
        p_site: site, p_product: p.id, p_kind: k, p_qty: round2(v),
        p_reference: k === 'entree' ? $('#mv-ref', root).value.trim() : '',
        p_note: $('#mv-note', root).value.trim(),
      });
      busy(e.target, false);
      if (error) return toast(errMsg(error), true);
      applyStock(p.id, site, data.stock_after);
      closeSheet();
      toast(`${kindLabel[k]} enregistrée · reste ${fmt(data.stock_after)}`);
      render();
    };
  });
}

function openStockSettings(p) {
  const site = S.site;
  const st = stockOf(p, site);
  openSheet(`
    <h2 id="sheet-title">Réglages · ${esc(siteShort(site))}</h2>
    <p class="muted small">${esc(p.name)}</p>
    <div class="field"><label for="ss-min">Seuil d'alerte</label><input type="text" inputmode="decimal" id="ss-min" value="${fmt(st.min_quantity)}"><span class="hint">Une alerte apparaît quand le stock descend à ce niveau. 0 = pas d'alerte.</span></div>
    <div class="field"><label for="ss-margin">Marge de sécurité pour les commandes</label><input type="text" inputmode="decimal" id="ss-margin" value="${fmt(st.safety_margin)}"><span class="hint">Quantité ajoutée à la proposition de commande.</span></div>
    <div class="field"><label for="ss-loc">Emplacement en réserve</label><input type="text" id="ss-loc" value="${esc(st.location)}" placeholder="Ex. : étagère B, 2e niveau"></div>
    <button type="button" class="btn primary block" id="ss-go">Enregistrer</button>`,
  (root) => {
    $('#ss-go', root).onclick = async (e) => {
      const min = parseNum($('#ss-min', root).value || '0'), mar = parseNum($('#ss-margin', root).value || '0');
      if (!(min >= 0) || !(mar >= 0)) return toast('Valeurs invalides.', true);
      busy(e.target, true);
      const upd = { min_quantity: round2(min), safety_margin: round2(mar), location: $('#ss-loc', root).value.trim() };
      const { error } = await S.sb.from('stocks').update(upd).eq('product_id', p.id).eq('site_id', site);
      busy(e.target, false);
      if (error) return toast(errMsg(error), true);
      Object.assign(p.stockBy[site] || (p.stockBy[site] = { quantity: 0 }), upd);
      closeSheet(); toast('Réglages enregistrés'); render();
    };
  });
}

// ---------------------------------------------------------------------
// STOCK
// ---------------------------------------------------------------------
function productRow(p, site = S.site) {
  const st = stockOf(p, site);
  let s = status(st);
  if (s === 'rupture' && !Number(st.min_quantity)) s = 'vide';
  return `<a class="item" href="#/p/${esc(p.code)}">
    <span class="stripe ${s}"></span>
    <span class="main-txt"><span class="title">${esc(p.name)}</span><span class="sub">${esc(p.packaging)}${st.location ? ' · ' + esc(st.location) : ''}${Number(st.min_quantity) ? ` · seuil ${fmt(st.min_quantity)}` : ''}</span></span>
    <span class="qty"><span class="n">${fmt(st.quantity)}</span>${s === 'bas' || s === 'rupture' ? pill(s) : ''}</span>
  </a>`;
}

async function renderStock(tok) {
  const f = S.filters;
  if (route()[1] === 'alertes') f.stockFam = 'Alertes';
  await refreshStocks();
  if (stale(tok)) return;
  main.innerHTML = `
    <div class="page-head"><div class="row"><h1>Stock ${esc(siteShort(S.site))}</h1><a class="btn small" href="#/inventaire">${ICON.count}Inventaire</a></div></div>
    ${searchBox('st-q', f.stockQ, 'Rechercher un produit')}
    ${famChips('st-fam', f.stockFam, ['Alertes'])}
    <p class="small muted" id="st-sum"></p>
    <div id="st-list"></div>`;
  const draw = () => {
    const list = activeProducts().filter((p) => matches(p, f.stockQ) && (f.stockFam === 'Tout' || (f.stockFam === 'Alertes' ? isAlert(p) : p.family === f.stockFam)));
    const al = activeProducts().filter((p) => isAlert(p)).length;
    $('#st-sum').textContent = `${list.length} produit${list.length > 1 ? 's' : ''} · ${al} sous le seuil d'alerte`;
    $('#st-list').innerHTML = list.length ? `<div class="list">${groupByFamily(list).map(([fam, ps]) => `<div class="group-label">${esc(fam)}</div>${ps.map((p) => productRow(p)).join('')}`).join('')}</div>`
      : `<div class="empty">${f.stockFam === 'Alertes' ? 'Aucun produit sous son seuil d\'alerte.' : 'Aucun produit ne correspond.'}</div>`;
  };
  draw();
  $('#st-q').oninput = (e) => { f.stockQ = e.target.value; draw(); };
  $('#st-fam').onclick = (e) => {
    const b = e.target.closest('[data-fam]');
    if (!b) return;
    f.stockFam = b.dataset.fam;
    $$('#st-fam .chip-btn').forEach((x) => x.setAttribute('aria-pressed', x === b));
    draw();
  };
}

// ---------------------------------------------------------------------
// DEMANDES (responsable)
// ---------------------------------------------------------------------
async function renderRequests(tok) {
  const [pending, done] = await Promise.all([
    S.sb.from('requests').select('*, request_items(*)').eq('site_id', S.site).eq('status', 'en_attente').order('created_at'),
    S.sb.from('requests').select('*, request_items(*)').eq('site_id', S.site).neq('status', 'en_attente').order('created_at', { ascending: false }).limit(30),
  ]);
  if (pending.error) throw pending.error;
  if (done.error) throw done.error;
  await refreshStocks();
  if (stale(tok)) return;
  S.pending = pending.data.length; renderTabs();
  const stLabel = { validee: ['ok', 'Remise'], refusee: ['danger', 'Refusée'], annulee: ['', 'Annulée'] };
  main.innerHTML = `
    ${backLink('#/accueil', 'Accueil')}
    <div class="page-head"><h1>Demandes · ${esc(siteShort(S.site))}</h1></div>
    <section class="section"><h2>En attente</h2>
      ${pending.data.length ? `<div class="list">${pending.data.map(requestItem).join('')}</div>` : '<div class="empty">Aucune demande en attente.</div>'}
    </section>
    <section class="section"><h2>Traitées récemment</h2>
      ${done.data.length ? `<div class="list">${done.data.map((r) => {
        const [cls, lab] = stLabel[r.status];
        const items = (r.request_items || []).map((it) => `${fmt(it.given ?? it.quantity)} × ${S.byId[it.product_id]?.name || 'Produit'}`).join(', ');
        return `<div class="item"><span class="main-txt"><span class="title">${esc(personName(r.requested_by))}</span><span class="sub">${esc(items)}</span>
          <span class="sub">${esc(dfTime.format(new Date(r.created_at)))}${r.handled_by ? ' · traitée par ' + esc(personName(r.handled_by)) : ''}${r.refuse_reason ? ' · ' + esc(r.refuse_reason) : ''}</span></span>
          <span class="qty"><span class="pill ${cls}">${lab}</span></span></div>`;
      }).join('')}</div>` : '<div class="empty">Rien pour l\'instant.</div>'}
    </section>`;
  bindRequestButtons(pending.data);
}

// ---------------------------------------------------------------------
// ENTRÉE (livraison)
// ---------------------------------------------------------------------
async function renderDelivery() {
  if (!canManage()) { main.innerHTML = '<div class="empty">Seul le responsable de ce site peut enregistrer une livraison.</div>'; return; }
  const draft = S.draftIn;
  let q = '';
  main.innerHTML = `
    ${backLink('#/plus', 'Plus')}
    <div class="page-head"><h1>Entrée de stock</h1><p class="muted">Livraison Adelya · ${esc(siteName(S.site))}. Saisissez les quantités reçues, puis enregistrez.</p></div>
    <div class="field"><label for="in-ref">N° de bon de livraison</label><input type="text" id="in-ref" value="${esc(S.draftInRef)}" autocomplete="off" placeholder="Facultatif"></div>
    ${searchBox('in-q', '', 'Rechercher un produit')}
    <div id="in-list"></div>
    <div class="cartbar" id="in-bar" hidden><button type="button" class="btn primary" id="in-go"></button></div>`;
  const draw = () => {
    const list = activeProducts().filter((p) => matches(p, q));
    $('#in-list').innerHTML = `<div class="list">${groupByFamily(list).map(([fam, ps]) => `<div class="group-label">${esc(fam)}</div>${ps.map((p) => `
      <div class="item"><span class="main-txt"><span class="title">${esc(p.name)}</span><span class="sub">${esc(p.packaging)} · en stock ${fmt(stockOf(p).quantity)}</span></span>${miniStepper(p.id, draft[p.id])}</div>`).join('')}`).join('')}</div>`;
  };
  const bar = () => {
    const n = Object.keys(draft).length;
    $('#in-bar').hidden = !n;
    $('#in-go').textContent = `Enregistrer la livraison · ${n} ligne${n > 1 ? 's' : ''}`;
  };
  draw(); bar();
  bindMiniSteppers($('#in-list'), draft, bar);
  $('#in-q').oninput = (e) => { q = e.target.value; draw(); };
  $('#in-ref').oninput = (e) => { S.draftInRef = e.target.value; };
  $('#in-go').onclick = () => {
    const ids = Object.keys(draft).filter((id) => S.byId[id]);
    openSheet(`<h2 id="sheet-title">Confirmer la livraison</h2>
      <p class="muted small">${esc(siteName(S.site))}${S.draftInRef ? ' · BL ' + esc(S.draftInRef) : ''}</p>
      <div class="list">${ids.map((id) => `<div class="item"><span class="main-txt"><span class="title">${esc(S.byId[id].name)}</span><span class="sub">${fmt(stockOf(S.byId[id]).quantity)} → ${fmt(round2(Number(stockOf(S.byId[id]).quantity) + draft[id]))}</span></span><span class="qty"><span class="delta pos">+${fmt(draft[id])}</span></span></div>`).join('')}</div>
      <button type="button" class="btn primary block" id="in-ok">Enregistrer l'entrée</button>
      <button type="button" class="btn ghost block" data-close-sheet>Modifier</button>`,
    (root) => {
      $('#in-ok', root).onclick = async (e) => {
        busy(e.target, true);
        const lines = ids.map((id) => ({ product_id: id, quantity: draft[id] }));
        const { error } = await S.sb.rpc('record_movements', { p_site: S.site, p_kind: 'entree', p_lines: lines, p_reference: S.draftInRef.trim(), p_note: 'Livraison' });
        busy(e.target, false);
        if (error) return toast(errMsg(error), true);
        for (const k of Object.keys(draft)) delete draft[k];
        S.draftInRef = '';
        await refreshStocks();
        closeSheet(); toast(`Livraison enregistrée · ${lines.length} produit${lines.length > 1 ? 's' : ''}`);
        go('#/accueil');
      };
    });
  };
}

// ---------------------------------------------------------------------
// INVENTAIRE
// ---------------------------------------------------------------------
async function renderInventory(tok) {
  if (!canManage()) { main.innerHTML = '<div class="empty">Seul le responsable de ce site peut faire l\'inventaire.</div>'; return; }
  await refreshStocks();
  if (stale(tok)) return;
  const key = `stock.inv.${S.site}`;
  const counts = lsGet(key, {});
  let fam = 'Tout';
  main.innerHTML = `
    ${backLink('#/plus', 'Plus')}
    <div class="page-head"><h1>Inventaire · ${esc(siteShort(S.site))}</h1>
    <p class="muted">Comptez ce qui est réellement en réserve et saisissez le chiffre. Laissez vide ce que vous n'avez pas compté. Votre saisie est gardée sur ce téléphone jusqu'à la validation.</p></div>
    ${famChips('inv-fam', fam)}
    <div class="table-wrap"><table><thead><tr><th>Produit</th><th class="n">Stock</th><th class="n">Compté</th><th class="n">Écart</th></tr></thead><tbody id="inv-body"></tbody></table></div>
    <div class="cartbar" id="inv-bar" hidden><button type="button" class="btn primary" id="inv-go"></button></div>`;
  const draw = () => {
    const list = activeProducts().filter((p) => fam === 'Tout' || p.family === fam);
    $('#inv-body').innerHTML = groupByFamily(list).map(([f, ps]) => `<tr><th colspan="4">${esc(f)}</th></tr>${ps.map((p) => {
      const th = Number(stockOf(p).quantity);
      const c = counts[p.id];
      const d = c != null ? round2(c - th) : null;
      return `<tr><td><strong>${esc(p.name)}</strong><br><span class="small muted">${esc(p.packaging)}</span></td>
        <td class="n">${fmt(th)}</td>
        <td class="n"><input type="text" inputmode="decimal" data-inv="${p.id}" value="${c != null ? fmt(c) : ''}" aria-label="Quantité comptée pour ${esc(p.name)}"></td>
        <td class="n" data-gap="${p.id}">${d == null ? '' : `<span class="delta ${d < 0 ? 'neg' : d > 0 ? 'pos' : ''}">${d > 0 ? '+' : ''}${fmt(d)}</span>`}</td></tr>`;
    }).join('')}`).join('');
  };
  const bar = () => {
    const n = Object.keys(counts).length;
    $('#inv-bar').hidden = !n;
    $('#inv-go').textContent = `Valider l'inventaire · ${n} produit${n > 1 ? 's' : ''} compté${n > 1 ? 's' : ''}`;
  };
  draw(); bar();
  $('#inv-body').addEventListener('change', (e) => {
    const inp = e.target.closest('[data-inv]');
    if (!inp) return;
    const id = inp.dataset.inv;
    const v = parseNum(inp.value);
    if (inp.value.trim() === '' || !Number.isFinite(v) || v < 0) { delete counts[id]; inp.value = ''; }
    else { counts[id] = round2(v); inp.value = fmt(v); }
    lsSet(key, counts);
    const th = Number(stockOf(S.byId[id]).quantity);
    const cell = $(`[data-gap="${id}"]`);
    const d = counts[id] != null ? round2(counts[id] - th) : null;
    cell.innerHTML = d == null ? '' : `<span class="delta ${d < 0 ? 'neg' : d > 0 ? 'pos' : ''}">${d > 0 ? '+' : ''}${fmt(d)}</span>`;
    bar();
  });
  $('#inv-fam').onclick = (e) => {
    const b = e.target.closest('[data-fam]');
    if (!b) return;
    fam = b.dataset.fam;
    $$('#inv-fam .chip-btn').forEach((x) => x.setAttribute('aria-pressed', x === b));
    draw();
  };
  $('#inv-go').onclick = () => {
    const ids = Object.keys(counts).filter((id) => S.byId[id]);
    const gaps = ids.map((id) => ({ id, d: round2(counts[id] - Number(stockOf(S.byId[id]).quantity)) }));
    const withGap = gaps.filter((g) => g.d !== 0);
    openSheet(`<h2 id="sheet-title">Valider l'inventaire</h2>
      <p>${ids.length} produit${ids.length > 1 ? 's' : ''} compté${ids.length > 1 ? 's' : ''}, dont <strong>${withGap.length}</strong> avec un écart.</p>
      ${withGap.length ? `<div class="list">${withGap.map((g) => `<div class="item"><span class="main-txt"><span class="title">${esc(S.byId[g.id].name)}</span><span class="sub">théorique ${fmt(stockOf(S.byId[g.id]).quantity)} · compté ${fmt(counts[g.id])}</span></span><span class="qty"><span class="delta ${g.d < 0 ? 'neg' : 'pos'}">${g.d > 0 ? '+' : ''}${fmt(g.d)}</span></span></div>`).join('')}</div>` : ''}
      <p class="small muted">Le stock de chaque produit compté sera remplacé par la quantité comptée. Les écarts restent visibles dans l'historique.</p>
      <button type="button" class="btn primary block" id="inv-ok">Valider</button>
      <button type="button" class="btn ghost block" data-close-sheet>Continuer à compter</button>`,
    (root) => {
      $('#inv-ok', root).onclick = async (e) => {
        busy(e.target, true);
        const lines = ids.map((id) => ({ product_id: id, quantity: counts[id] }));
        const { error } = await S.sb.rpc('record_movements', { p_site: S.site, p_kind: 'inventaire', p_lines: lines, p_reference: '', p_note: 'Inventaire' });
        busy(e.target, false);
        if (error) return toast(errMsg(error), true);
        lsDel(key);
        await refreshStocks();
        closeSheet(); toast('Inventaire enregistré');
        go('#/stock');
      };
    });
  };
}

// ---------------------------------------------------------------------
// HISTORIQUE
// ---------------------------------------------------------------------
async function fetchMovements(site, fromDate, toDate) {
  return fetchAll(() => {
    let q = S.sb.from('movements').select('*').order('created_at', { ascending: false });
    if (site) q = q.eq('site_id', site);
    if (fromDate) q = q.gte('created_at', fromDate.toISOString());
    if (toDate) q = q.lt('created_at', toDate.toISOString());
    return q;
  });
}
function movementsCSV(list) {
  return toCSV([
    ['Date', 'Heure', 'Site', 'Code', 'Produit', 'Conditionnement', 'Type', 'Quantité saisie', 'Variation', 'Stock avant', 'Stock après', 'Personne', 'Bon de livraison', 'Note'],
    ...list.map((m) => {
      const p = S.byId[m.product_id] || {};
      const d = new Date(m.created_at);
      return [dfShort.format(d), dfHour.format(d), siteShort(m.site_id), p.code || '', p.name || '', p.packaging || '', kindLabel[m.kind],
        Number(m.quantity), Number(m.delta), Number(m.stock_before), Number(m.stock_after), personName(m.user_id), m.reference, m.note];
    }),
  ]);
}

async function renderHistory(tok) {
  const f = S.filters;
  main.innerHTML = `
    <div class="page-head"><div class="row"><h1>Historique · ${esc(siteShort(S.site))}</h1><button type="button" class="btn small" id="h-csv">${ICON.download}Exporter</button></div></div>
    <div class="seg" id="h-period">${[[7, '7 jours'], [30, '30 jours'], [90, '3 mois'], [365, '1 an']].map(([d, l]) => `<button type="button" data-d="${d}" aria-pressed="${f.histPeriod === d}">${l}</button>`).join('')}</div>
    <div class="chips" id="h-kind">${[['tout', 'Tout'], ['sortie', 'Sorties'], ['entree', 'Entrées'], ['inventaire', 'Inventaires']].map(([k, l]) => `<button type="button" class="chip-btn" data-k="${k}" aria-pressed="${f.histKind === k}">${l}</button>`).join('')}</div>
    ${searchBox('h-q', f.histQ, 'Filtrer par produit ou personne')}
    <p class="small muted" id="h-sum">Chargement…</p>
    <div id="h-list"></div>`;
  let data = [];
  const filtered = () => data.filter((m) => (f.histKind === 'tout' || m.kind === f.histKind) && (!f.histQ || (() => {
    const p = S.byId[m.product_id];
    const hay = `${p?.name || ''} ${p?.code || ''} ${personName(m.user_id)} ${m.note} ${m.reference}`.toLowerCase();
    return f.histQ.toLowerCase().split(/\s+/).every((w) => hay.includes(w));
  })()));
  const draw = () => {
    const list = filtered();
    const outs = list.filter((m) => m.kind === 'sortie').length, ins = list.filter((m) => m.kind === 'entree').length;
    $('#h-sum').textContent = `${list.length} mouvement${list.length > 1 ? 's' : ''} · ${outs} sortie${outs > 1 ? 's' : ''} · ${ins} entrée${ins > 1 ? 's' : ''}`;
    const byDay = new Map();
    for (const m of list.slice(0, 400)) {
      const k = cap(dfDay.format(new Date(m.created_at)));
      if (!byDay.has(k)) byDay.set(k, []);
      byDay.get(k).push(m);
    }
    $('#h-list').innerHTML = list.length ? `<div class="list">${[...byDay.entries()].map(([d, ms]) => `<div class="group-label">${esc(d)}</div>${ms.map((m) => movementItem(m)).join('')}`).join('')}</div>${list.length > 400 ? '<p class="small muted">Les 400 premiers sont affichés. L\'export contient tout.</p>' : ''}`
      : '<div class="empty">Aucun mouvement sur cette période.</div>';
  };
  const load = async () => {
    $('#h-sum').textContent = 'Chargement…';
    const since = new Date(Date.now() - f.histPeriod * DAY);
    const rows = await fetchMovements(S.site, since);
    if (stale(tok)) return;
    data = rows;
    draw();
  };
  $('#h-period').onclick = (e) => {
    const b = e.target.closest('[data-d]');
    if (!b) return;
    f.histPeriod = Number(b.dataset.d);
    $$('#h-period button').forEach((x) => x.setAttribute('aria-pressed', x === b));
    load().catch((err) => toast(errMsg(err), true));
  };
  $('#h-kind').onclick = (e) => {
    const b = e.target.closest('[data-k]');
    if (!b) return;
    f.histKind = b.dataset.k;
    $$('#h-kind .chip-btn').forEach((x) => x.setAttribute('aria-pressed', x === b));
    draw();
  };
  $('#h-q').oninput = (e) => { f.histQ = e.target.value; draw(); };
  $('#h-csv').onclick = () => {
    const list = filtered();
    if (!list.length) return toast('Rien à exporter.', true);
    download(`mouvements-${siteShort(S.site).toLowerCase()}-${isoDate(new Date())}.csv`, movementsCSV(list));
  };
  await load();
}

// ---------------------------------------------------------------------
// FICHES DE SÉCURITÉ
// ---------------------------------------------------------------------
async function renderSheets() {
  let q = '';
  const chem = activeProducts().filter((p) => p.chemical || p.signal_word || (p.pictograms || []).length || p.sheetCount);
  const missing = chem.filter((p) => !p.sheetCount).length;
  main.innerHTML = `
    ${isResp() ? backLink('#/plus', 'Plus') : ''}
    <div class="page-head"><h1>Fiches de sécurité</h1><p class="muted">${chem.length} produits chimiques${missing ? ` · ${missing} fiche${missing > 1 ? 's' : ''} encore à ajouter` : ''}</p></div>
    ${searchBox('sh-q', '', 'Rechercher un produit')}
    <div id="sh-list"></div>`;
  const draw = () => {
    const list = chem.filter((p) => matches(p, q));
    $('#sh-list').innerHTML = list.length ? `<div class="list">${list.map((p) => `
      <a class="item" href="#/p/${esc(p.code)}">
        <span class="main-txt"><span class="title">${esc(p.name)}</span>
          <span class="sub">${esc(p.packaging)}</span>
          ${(p.pictograms || []).length ? `<span class="row" style="gap:4px;margin-top:4px">${p.pictograms.map((c) => picto(c, 28)).join('')}</span>` : ''}</span>
        <span class="qty">${p.signal_word ? `<span class="pill ${p.signal_word === 'Danger' ? 'danger' : 'warn'}">${esc(p.signal_word)}</span>` : ''}
          ${p.sheetCount ? '<span class="pill ok">Fiche</span>' : '<span class="pill">Sans fiche</span>'}</span>
      </a>`).join('')}</div>` : '<div class="empty">Aucun produit ne correspond.</div>';
  };
  draw();
  $('#sh-q').oninput = (e) => { q = e.target.value; draw(); };
}

// ---------------------------------------------------------------------
// PLUS
// ---------------------------------------------------------------------
async function renderMore() {
  const link = (h, icon, t, s) => `<a class="item" href="${h}"><span class="mv-icon inventaire">${icon.replace('<svg', '<svg width="22" height="22"')}</span><span class="main-txt"><span class="title">${t}</span><span class="sub">${s}</span></span>${ICON.chevron.replace('<svg', '<svg width="20" height="20" style="color:var(--muted)"')}</a>`;
  main.innerHTML = `
    <div class="page-head"><h1>Plus</h1></div>
    <section class="section"><h2>Stock ${esc(siteShort(S.site))}</h2><div class="list">
      ${link('#/demandes', ICON.ask, 'Demandes', S.pending ? `${S.pending} en attente` : 'Aucune en attente')}
      ${canManage() ? link('#/entree', ICON.in, 'Entrée de stock', 'Enregistrer une livraison Adelya') : ''}
      ${canManage() ? link('#/inventaire', ICON.count, 'Inventaire', 'Compter le stock réel') : ''}
      ${link('#/fiches', ICON.shield, 'Fiches de sécurité', 'Consignes et FDS de chaque produit')}
      ${link('#/etiquettes', ICON.tag, 'Étiquettes QR', 'Imprimer les étiquettes des étagères')}
      ${link('#/exports', ICON.download, 'Exports', 'Fichiers pour Excel')}
    </div></section>
    ${isSecteur() ? `<section class="section"><h2>Gestion du secteur</h2><div class="list">
      ${link('#/commande', ICON.order, 'Aide à la commande', 'Quantités à commander à Adelya')}
      ${link('#/produits', ICON.products, 'Produits', 'Ajouter, modifier, archiver')}
      ${link('#/utilisateurs', ICON.users, 'Utilisateurs', S.pendingUsers ? `${S.pendingUsers} compte${S.pendingUsers > 1 ? 's' : ''} à valider` : 'Rôles et accès')}
    </div></section>` : ''}
    <section class="section"><div class="list">${link('#/compte', ICON.user, 'Mon compte', esc(S.me.full_name))}</div></section>`;
}

// ---------------------------------------------------------------------
// ÉTIQUETTES QR
// ---------------------------------------------------------------------
function appBaseUrl() { return location.href.split('#')[0].split('?')[0].replace(/index\.html$/, ''); }
function qrSvg(text) {
  const qr = window.qrcode(0, 'M');
  qr.addData(text);
  qr.make();
  const n = qr.getModuleCount();
  let d = '';
  for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (qr.isDark(r, c)) d += `M${c + 2} ${r + 2}h1v1h-1z`;
  return `<svg viewBox="0 0 ${n + 4} ${n + 4}" shape-rendering="crispEdges" role="img" aria-label="QR code"><rect width="100%" height="100%" fill="#fff"/><path d="${d}" fill="#000"/></svg>`;
}
async function renderLabels() {
  let fam = 'Tout';
  main.innerHTML = `
    <div class="no-print stack">
      ${backLink('#/plus', 'Plus')}
      <div class="page-head"><div class="row"><h1>Étiquettes QR</h1><button type="button" class="btn primary small" id="lb-print">Imprimer</button></div>
      <p class="muted">Une étiquette par produit, à coller sur l'étagère. Le scan ouvre la fiche du produit. Imprimez depuis un ordinateur sur du papier adhésif A4 (3 colonnes).</p></div>
      ${famChips('lb-fam', fam)}
    </div>
    <div class="labels" id="lb-list"></div>`;
  const base = appBaseUrl();
  const draw = () => {
    const list = activeProducts().filter((p) => fam === 'Tout' || p.family === fam);
    $('#lb-list').innerHTML = list.map((p) => `<div class="label-card">${qrSvg(`${base}#/p/${p.code}`)}<div><div class="ln">${esc(p.name)}</div><div class="lc">${esc(p.code)}</div><div class="lp">${esc(p.packaging)}</div>${p.signal_word ? `<div class="ls">${esc(p.signal_word)}</div>` : ''}</div></div>`).join('');
  };
  draw();
  $('#lb-fam').onclick = (e) => {
    const b = e.target.closest('[data-fam]');
    if (!b) return;
    fam = b.dataset.fam;
    $$('#lb-fam .chip-btn').forEach((x) => x.setAttribute('aria-pressed', x === b));
    draw();
  };
  $('#lb-print').onclick = () => window.print();
}

// ---------------------------------------------------------------------
// EXPORTS
// ---------------------------------------------------------------------
async function renderExports() {
  const today = new Date();
  const monthAgo = new Date(Date.now() - 30 * DAY);
  const siteOpts = isSecteur() ? `<div class="field"><label for="ex-site">Site</label><select id="ex-site"><option value="${S.site}">${esc(siteName(S.site))}</option><option value="all">Les deux sites</option></select></div>` : '';
  main.innerHTML = `
    ${backLink('#/plus', 'Plus')}
    <div class="page-head"><h1>Exports</h1><p class="muted">Fichiers CSV qui s'ouvrent dans Excel.</p></div>
    ${siteOpts}
    <div class="card stack"><h2>État du stock</h2><p class="muted small">Stock actuel, seuil et statut de chaque produit.</p>
      <button type="button" class="btn" id="ex-stock">${ICON.download}Télécharger</button></div>
    <div class="card stack"><h2>Mouvements et consommation</h2>
      <div class="grid-2">
        <div class="field"><label for="ex-from">Du</label><input type="date" id="ex-from" value="${isoDate(monthAgo)}"></div>
        <div class="field"><label for="ex-to">Au</label><input type="date" id="ex-to" value="${isoDate(today)}"></div>
      </div>
      <button type="button" class="btn" id="ex-mv">${ICON.download}Tous les mouvements</button>
      <button type="button" class="btn" id="ex-cons">${ICON.download}Consommation par produit</button></div>`;
  const sites = () => (isSecteur() && $('#ex-site')?.value === 'all') ? S.sites.map((s) => s.id) : [S.site];
  const range = () => {
    const from = new Date($('#ex-from').value + 'T00:00:00');
    const to = new Date(new Date($('#ex-to').value + 'T00:00:00').getTime() + DAY);
    if (isNaN(from) || isNaN(to) || to <= from) throw new Error('Période invalide.');
    return [from, to];
  };
  const tag = () => (sites().length > 1 ? 'secteur' : siteShort(S.site).toLowerCase());
  $('#ex-stock').onclick = async () => {
    await refreshStocks();
    const rows = [['Site', 'Code', 'Famille', 'Produit', 'Conditionnement', 'Réf. Adelya', 'Stock', 'Seuil', 'Statut', 'Emplacement']];
    for (const s of sites()) for (const p of activeProducts()) {
      const st = stockOf(p, s);
      rows.push([siteShort(s), p.code, p.family, p.name, p.packaging, p.adelya_ref, Number(st.quantity), Number(st.min_quantity), STATUS_LABEL[status(st)], st.location]);
    }
    download(`stock-${tag()}-${isoDate(new Date())}.csv`, toCSV(rows));
  };
  $('#ex-mv').onclick = async (e) => {
    const btn = e.currentTarget;
    try {
      const [from, to] = range();
      busy(btn, true, 'Préparation…');
      let all = [];
      for (const s of sites()) all = all.concat(await fetchMovements(s, from, to));
      all.sort((a, b) => a.created_at.localeCompare(b.created_at));
      download(`mouvements-${tag()}-${$('#ex-from').value}-au-${$('#ex-to').value}.csv`, movementsCSV(all));
    } catch (err) { toast(errMsg(err), true); }
    busy(btn, false);
  };
  $('#ex-cons').onclick = async (e) => {
    const btn = e.currentTarget;
    try {
      const [from, to] = range();
      busy(btn, true, 'Préparation…');
      const rows = [['Site', 'Code', 'Famille', 'Produit', 'Conditionnement', 'Sorties', 'Nombre de sorties', 'Entrées', 'Écarts d\'inventaire', 'Stock actuel']];
      for (const s of sites()) {
        const mv = await fetchMovements(s, from, to);
        const agg = {};
        for (const m of mv) {
          const a = agg[m.product_id] || (agg[m.product_id] = { out: 0, n: 0, inn: 0, gap: 0 });
          if (m.kind === 'sortie') { a.out += Number(m.quantity); a.n += 1; }
          else if (m.kind === 'entree') a.inn += Number(m.quantity);
          else a.gap += Number(m.delta);
        }
        for (const p of activeProducts()) {
          const a = agg[p.id] || { out: 0, n: 0, inn: 0, gap: 0 };
          rows.push([siteShort(s), p.code, p.family, p.name, p.packaging, round2(a.out), a.n, round2(a.inn), round2(a.gap), Number(stockOf(p, s).quantity)]);
        }
      }
      download(`consommation-${tag()}-${$('#ex-from').value}-au-${$('#ex-to').value}.csv`, toCSV(rows));
    } catch (err) { toast(errMsg(err), true); }
    busy(btn, false);
  };
}

// ---------------------------------------------------------------------
// AIDE À LA COMMANDE (secteur)
// ---------------------------------------------------------------------
async function computeOrder(site, nextOrder, followingOrder) {
  const since = new Date(Date.now() - 180 * DAY);
  const mv = await fetchMovements(site, since);
  const first = await S.sb.from('movements').select('created_at').eq('site_id', site).order('created_at').limit(1);
  const start = first.data && first.data[0] ? new Date(Math.max(since.getTime(), new Date(first.data[0].created_at).getTime())) : null;
  const days = start ? Math.max(14, (Date.now() - start) / DAY) : 0;
  const months = Math.max(0, (followingOrder - new Date()) / DAY / 30.44);
  const out = {};
  for (const m of mv) if (m.kind === 'sortie') out[m.product_id] = (out[m.product_id] || 0) + Number(m.quantity);
  const lines = activeProducts().map((p) => {
    const st = stockOf(p, site);
    const monthly = days ? (out[p.id] || 0) / days * 30.44 : 0;
    const need = monthly * months + Number(st.safety_margin) - Number(st.quantity);
    return { p, monthly, stock: Number(st.quantity), margin: Number(st.safety_margin), proposed: Math.max(0, Math.ceil(need - 1e-9)) };
  });
  return { lines, days, start, months };
}

async function renderOrder(tok) {
  const s = S.settings || { next_order: '2027-03-15', following_order: '2027-10-15' };
  main.innerHTML = `
    ${backLink('#/plus', 'Plus')}
    <div class="page-head"><h1>Aide à la commande</h1>
    <p class="muted">Quantité proposée = sorties par mois × mois jusqu'à la commande d'après + marge − stock actuel.</p></div>
    <div class="card stack">
      <div class="grid-2">
        <div class="field"><label for="or-next">Prochaine commande</label><input type="date" id="or-next" value="${esc(s.next_order)}"></div>
        <div class="field"><label for="or-follow">Commande d'après</label><input type="date" id="or-follow" value="${esc(s.following_order)}"></div>
      </div>
      <button type="button" class="btn small" id="or-save">Enregistrer les dates</button>
    </div>
    <p id="or-basis" class="small muted">Calcul en cours…</p>
    <div id="or-table"></div>
    <div class="grid-2 no-print">
      <button type="button" class="btn primary" id="or-csv">${ICON.download}Exporter ce site</button>
      <button type="button" class="btn" id="or-csv-all">${ICON.download}Exporter les deux sites</button>
    </div>`;
  let current = null;
  const edits = {};
  const draw = (res) => {
    const { lines, days, start, months } = res;
    const nextD = new Date(s.next_order + 'T00:00:00'), folD = new Date(s.following_order + 'T00:00:00');
    $('#or-basis').innerHTML = days
      ? `${esc(siteName(S.site))} · calculé sur <strong>${Math.round(days)} jours</strong> de sorties (depuis le ${esc(dfDate.format(start))}). Prochaine commande le ${esc(dfDate.format(nextD))}, commande d'après le ${esc(dfDate.format(folD))} : <strong>${fmt(round2(months))} mois</strong> à couvrir.${days < 60 ? ' <span style="color:var(--warn);font-weight:700">Peu de recul : vérifiez les quantités.</span>' : ''}`
      : `<span class="notice">Pas encore de mouvements sur ${esc(siteShort(S.site))} : la proposition ne tient compte que des marges. Faites l'inventaire de départ et enregistrez les sorties pendant quelques semaines.</span>`;
    $('#or-table').innerHTML = `<div class="table-wrap"><table><thead><tr><th>Produit</th><th class="n">Conso / mois</th><th class="n">Stock</th><th class="n">Commande</th></tr></thead><tbody>
      ${groupByFamily(lines.map((l) => l.p)).map(([fam, ps]) => `<tr><th colspan="4">${esc(fam)}</th></tr>${ps.map((p) => {
        const l = lines.find((x) => x.p === p);
        const v = edits[p.id] ?? l.proposed;
        return `<tr><td><strong>${esc(p.name)}</strong><br><span class="small muted">${esc(p.packaging)}${l.margin ? ` · marge ${fmt(l.margin)}` : ''}</span></td>
          <td class="n">${l.monthly ? fmt(round2(l.monthly)) : '—'}</td><td class="n">${fmt(l.stock)}</td>
          <td class="n"><input type="text" inputmode="decimal" data-or="${p.id}" value="${fmt(v)}" aria-label="Quantité à commander pour ${esc(p.name)}"></td></tr>`;
      }).join('')}`).join('')}</tbody></table></div>`;
  };
  const load = async () => {
    const res = await computeOrder(S.site, new Date(s.next_order + 'T00:00:00'), new Date(s.following_order + 'T00:00:00'));
    if (stale(tok)) return;
    current = res;
    draw(res);
  };
  $('#or-table').addEventListener('change', (e) => {
    const inp = e.target.closest('[data-or]');
    if (!inp) return;
    const v = parseNum(inp.value);
    edits[inp.dataset.or] = Number.isFinite(v) && v >= 0 ? round2(v) : 0;
    inp.value = fmt(edits[inp.dataset.or]);
  });
  $('#or-save').onclick = async (e) => {
    const n = $('#or-next').value, fo = $('#or-follow').value;
    if (!n || !fo || fo <= n) return toast('La commande d\'après doit être après la prochaine commande.', true);
    busy(e.target, true);
    const { error } = await S.sb.from('settings').update({ next_order: n, following_order: fo, updated_at: new Date().toISOString() }).eq('id', 1);
    busy(e.target, false);
    if (error) return toast(errMsg(error), true);
    s.next_order = n; s.following_order = fo; S.settings = s;
    toast('Dates enregistrées');
    load();
  };
  const header = ['Famille', 'Code', 'Produit', 'Conditionnement', 'Ligne BPU', 'Réf. Adelya'];
  $('#or-csv').onclick = () => {
    if (!current) return;
    const rows = [[...header, 'Sorties par mois', 'Stock', 'Quantité à commander']];
    for (const l of current.lines) {
      const q = edits[l.p.id] ?? l.proposed;
      rows.push([l.p.family, l.p.code, l.p.name, l.p.packaging, l.p.bpu_line ?? '', l.p.adelya_ref, round2(l.monthly), l.stock, q]);
    }
    download(`commande-${siteShort(S.site).toLowerCase()}-${s.next_order}.csv`, toCSV(rows));
  };
  $('#or-csv-all').onclick = async (e) => {
    const btn = e.currentTarget;
    busy(btn, true, 'Calcul…');
    try {
      const nx = new Date(s.next_order + 'T00:00:00'), fo = new Date(s.following_order + 'T00:00:00');
      const per = {};
      for (const site of S.sites) {
        const r = site.id === S.site && current ? current : await computeOrder(site.id, nx, fo);
        per[site.id] = Object.fromEntries(r.lines.map((l) => [l.p.id, site.id === S.site ? (edits[l.p.id] ?? l.proposed) : l.proposed]));
      }
      const rows = [[...header, ...S.sites.map((x) => x.short_name), 'Total']];
      for (const p of activeProducts()) {
        const q = S.sites.map((x) => per[x.id][p.id] || 0);
        rows.push([p.family, p.code, p.name, p.packaging, p.bpu_line ?? '', p.adelya_ref, ...q, round2(q.reduce((a, b) => a + b, 0))]);
      }
      download(`commande-secteur-${s.next_order}.csv`, toCSV(rows));
    } catch (err) { toast(errMsg(err), true); }
    busy(btn, false);
  };
  await load();
}

// ---------------------------------------------------------------------
// PRODUITS (secteur)
// ---------------------------------------------------------------------
async function renderProductsAdmin() {
  let q = '';
  let showArchived = false;
  main.innerHTML = `
    ${backLink('#/plus', 'Plus')}
    <div class="page-head"><div class="row"><h1>Produits</h1><a class="btn primary small" href="#/produit/nouveau">${ICON.plus}Ajouter</a></div>
    <p class="muted">${activeProducts().length} produits actifs. Un produit archivé n'apparaît plus dans les listes mais garde son historique.</p></div>
    ${searchBox('pa-q', '', 'Rechercher')}
    <label class="switch-row"><span>Afficher les produits archivés</span><input type="checkbox" id="pa-arch"></label>
    <div id="pa-list"></div>`;
  const draw = () => {
    const list = S.products.filter((p) => (showArchived || p.active) && matches(p, q));
    $('#pa-list').innerHTML = list.length ? `<div class="list">${groupByFamily(list).map(([fam, ps]) => `<div class="group-label">${esc(fam)}</div>${ps.map((p) => `
      <a class="item" href="#/produit/${p.id}/modifier"><span class="main-txt"><span class="title">${esc(p.name)}${p.active ? '' : ' (archivé)'}</span>
      <span class="sub"><span class="mono">${esc(p.code)}</span> · ${esc(p.packaging)}${p.bpu_line ? ` · BPU ${p.bpu_line}` : ''}</span></span>
      <span class="qty">${p.chemical ? (p.sheetCount ? '<span class="pill ok">FDS</span>' : '<span class="pill warn">Sans FDS</span>') : ''}</span></a>`).join('')}`).join('')}</div>`
      : '<div class="empty">Aucun produit.</div>';
  };
  draw();
  $('#pa-q').oninput = (e) => { q = e.target.value; draw(); };
  $('#pa-arch').onchange = (e) => { showArchived = e.target.checked; draw(); };
}

function nextCode(family) {
  const prefix = (family || 'DIV').normalize('NFD').replace(/[̀-ͯ]/g, '').toUpperCase().replace(/[^A-Z]/g, '').slice(0, 3) || 'DIV';
  const existing = S.products.find((p) => p.family === family);
  const pre = existing ? existing.code.split('-')[0] : prefix;
  let n = 1;
  while (S.byCode[`${pre}-${String(n).padStart(2, '0')}`]) n++;
  return `${pre}-${String(n).padStart(2, '0')}`;
}

async function renderProductForm(id) {
  const isNew = id === 'nouveau';
  const p = isNew ? { code: '', name: '', family: families()[0] || '', packaging: '', bpu_line: null, adelya_ref: '', chemical: false, signal_word: '', pictograms: [], ppe: [], hazards: '', first_aid: '', incompat: '', storage: '', active: true } : S.byId[id];
  if (!p) { main.innerHTML = `${backLink('#/produits', 'Produits')}<div class="empty">Produit introuvable.</div>`; return; }
  const fams = [...new Set(S.products.map((x) => x.family))];
  main.innerHTML = `
    ${backLink(isNew ? '#/produits' : `#/p/${p.code}`, isNew ? 'Produits' : p.name)}
    <div class="page-head"><h1>${isNew ? 'Nouveau produit' : 'Modifier le produit'}</h1></div>
    <form id="pf" class="stack" novalidate>
      <div class="card stack">
        <h2>Identification</h2>
        <div class="field"><label for="pf-name">Nom</label><input type="text" id="pf-name" value="${esc(p.name)}" required></div>
        <div class="grid-2">
          <div class="field"><label for="pf-family">Famille</label><input type="text" id="pf-family" value="${esc(p.family)}" list="pf-fams" required><datalist id="pf-fams">${fams.map((f) => `<option value="${esc(f)}">`).join('')}</datalist></div>
          <div class="field"><label for="pf-code">Code</label><input type="text" id="pf-code" value="${esc(p.code)}" autocapitalize="characters" placeholder="Auto"></div>
        </div>
        <div class="field"><label for="pf-pack">Conditionnement</label><input type="text" id="pf-pack" value="${esc(p.packaging)}" placeholder="Ex. : Bidon 5 L"></div>
        <div class="grid-2">
          <div class="field"><label for="pf-bpu">Ligne BPU</label><input type="text" inputmode="numeric" id="pf-bpu" value="${p.bpu_line ?? ''}"></div>
          <div class="field"><label for="pf-ref">Réf. Adelya</label><input type="text" id="pf-ref" value="${esc(p.adelya_ref)}"></div>
        </div>
        <label class="switch-row"><span><strong>Produit chimique</strong><br><span class="small muted">Une fiche de sécurité est attendue.</span></span><input type="checkbox" id="pf-chem" ${p.chemical ? 'checked' : ''}></label>
        ${isNew ? '' : `<label class="switch-row"><span><strong>Actif</strong><br><span class="small muted">Décochez pour archiver le produit.</span></span><input type="checkbox" id="pf-active" ${p.active ? 'checked' : ''}></label>`}
      </div>
      <div class="card stack">
        <h2>Sécurité</h2>
        <p class="small muted">Recopiez les éléments de l'étiquette ou de la fiche de sécurité (rubriques 2, 4, 7 et 10).</p>
        <div class="field"><label for="pf-signal">Mention d'avertissement</label><select id="pf-signal">
          <option value="" ${!p.signal_word ? 'selected' : ''}>Aucune</option>
          <option ${p.signal_word === 'Attention' ? 'selected' : ''}>Attention</option>
          <option ${p.signal_word === 'Danger' ? 'selected' : ''}>Danger</option></select></div>
        <div class="field"><span class="label">Pictogrammes</span><div class="checkgrid">${Object.keys(PICTOS).map((c) => `<label><input type="checkbox" name="picto" value="${c}" ${(p.pictograms || []).includes(c) ? 'checked' : ''}>${picto(c)}<span class="small">${esc(PICTOS[c].label)}</span></label>`).join('')}</div></div>
        <div class="field"><span class="label">Protections à porter</span><div class="checkgrid">${PPE.map((x) => `<label><input type="checkbox" name="ppe" value="${esc(x)}" ${(p.ppe || []).includes(x) ? 'checked' : ''}>${esc(x)}</label>`).join('')}</div></div>
        <div class="field"><label for="pf-haz">Dangers</label><textarea id="pf-haz" placeholder="Ex. : provoque une sévère irritation des yeux">${esc(p.hazards)}</textarea></div>
        <div class="field"><label for="pf-inc">Ne jamais mélanger avec</label><textarea id="pf-inc" placeholder="Ex. : javel, produits acides">${esc(p.incompat)}</textarea></div>
        <div class="field"><label for="pf-aid">Premiers secours</label><textarea id="pf-aid" placeholder="Ex. : yeux : rincer 15 minutes à l'eau">${esc(p.first_aid)}</textarea></div>
        <div class="field"><label for="pf-sto">Stockage</label><textarea id="pf-sto" placeholder="Ex. : au frais, à l'abri du gel">${esc(p.storage)}</textarea></div>
      </div>
      <button type="submit" class="btn primary block" id="pf-go">${isNew ? 'Créer le produit' : 'Enregistrer'}</button>
    </form>`;
  $('#pf-family').addEventListener('change', () => {
    if (isNew && !$('#pf-code').value.trim()) $('#pf-code').placeholder = nextCode($('#pf-family').value.trim());
  });
  if (isNew) $('#pf-code').placeholder = nextCode(p.family);
  $('#pf').onsubmit = async (e) => {
    e.preventDefault();
    const name = $('#pf-name').value.trim();
    const family = $('#pf-family').value.trim();
    if (!name || !family) return toast('Le nom et la famille sont obligatoires.', true);
    let code = ($('#pf-code').value.trim() || (isNew ? nextCode(family) : p.code)).toUpperCase().replace(/\s+/g, '-');
    if (!/^[A-Z0-9-]{2,20}$/.test(code)) return toast('Code invalide : lettres, chiffres et tirets uniquement.', true);
    const bpu = $('#pf-bpu').value.trim();
    const row = {
      code, name, family,
      packaging: $('#pf-pack').value.trim(),
      bpu_line: bpu ? parseInt(bpu, 10) || null : null,
      adelya_ref: $('#pf-ref').value.trim(),
      chemical: $('#pf-chem').checked,
      signal_word: $('#pf-signal').value,
      pictograms: $$('input[name=picto]:checked').map((x) => x.value),
      ppe: $$('input[name=ppe]:checked').map((x) => x.value),
      hazards: $('#pf-haz').value.trim(),
      incompat: $('#pf-inc').value.trim(),
      first_aid: $('#pf-aid').value.trim(),
      storage: $('#pf-sto').value.trim(),
    };
    if (!isNew) row.active = $('#pf-active').checked;
    const btn = $('#pf-go');
    busy(btn, true);
    const res = isNew ? await S.sb.from('products').insert(row) : await S.sb.from('products').update(row).eq('id', p.id);
    if (res.error) { busy(btn, false); return toast(errMsg(res.error), true); }
    await reloadProducts();
    toast(isNew ? 'Produit créé' : 'Produit enregistré');
    go(`#/p/${code}`);
  };
}

// ---------------------------------------------------------------------
// UTILISATEURS (secteur)
// ---------------------------------------------------------------------
const ROLE_LABEL = { secteur: 'Responsable de secteur', responsable: 'Responsable d\'installation', agent: 'Agent d\'entretien' };
async function renderUsers(tok) {
  const { data, error } = await S.sb.from('profiles').select('*').order('created_at');
  if (error) throw error;
  if (stale(tok)) return;
  S.profiles = Object.fromEntries(data.map((p) => [p.id, p]));
  const pending = data.filter((p) => !p.active);
  const active = data.filter((p) => p.active);
  S.pendingUsers = pending.length; renderTabs();
  const userRow = (u) => `<button type="button" class="item" data-user="${u.id}">
    <span class="main-txt"><span class="title">${esc(u.full_name)}${u.id === S.me.id ? ' (vous)' : ''}</span>
    <span class="sub">${esc(ROLE_LABEL[u.role])}${u.site_id ? ' · ' + esc(siteShort(u.site_id)) : ''}</span></span>
    <span class="qty">${u.active ? '' : '<span class="pill warn">À valider</span>'}</span></button>`;
  main.innerHTML = `
    ${backLink('#/plus', 'Plus')}
    <div class="page-head"><h1>Utilisateurs</h1>
    <p class="muted">Chaque personne crée son compte depuis l'adresse de l'application, puis vous validez son accès ici en choisissant son rôle et son site.</p></div>
    <div class="notice info" style="display:block">Adresse à partager à l'équipe :<br><span class="mono" style="overflow-wrap:anywhere">${esc(appBaseUrl())}</span></div>
    <section class="section"><h2>En attente de validation</h2>
      ${pending.length ? `<div class="list">${pending.map(userRow).join('')}</div>` : '<div class="empty">Aucun compte en attente.</div>'}</section>
    <section class="section"><h2>Comptes actifs</h2><div class="list">${active.map(userRow).join('')}</div></section>`;
  $$('[data-user]', main).forEach((b) => { b.onclick = () => openUser(S.profiles[b.dataset.user]); });
}
function openUser(u) {
  const self = u.id === S.me.id;
  openSheet(`
    <h2 id="sheet-title">${esc(u.full_name)}</h2>
    ${self ? '<p class="notice info">Vous ne pouvez pas modifier votre propre rôle.</p>' : ''}
    <div class="field"><label for="u-role">Rôle</label><select id="u-role" ${self ? 'disabled' : ''}>
      ${Object.entries(ROLE_LABEL).map(([k, l]) => `<option value="${k}" ${u.role === k ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
    <div class="field" id="u-site-f"><label for="u-site">Site</label><select id="u-site" ${self ? 'disabled' : ''}>
      ${S.sites.map((s) => `<option value="${s.id}" ${u.site_id === s.id ? 'selected' : ''}>${esc(s.name)}</option>`).join('')}</select></div>
    ${self ? '' : `<button type="button" class="btn primary block" id="u-go">${u.active ? 'Enregistrer' : 'Valider l\'accès'}</button>
    ${u.active ? '<button type="button" class="btn danger block" id="u-off">Retirer l\'accès</button>' : '<button type="button" class="btn ghost block" id="u-del">Refuser ce compte</button>'}`}`,
  (root) => {
    const roleSel = $('#u-role', root);
    const syncSite = () => { $('#u-site-f', root).hidden = roleSel.value === 'secteur'; };
    syncSite();
    roleSel.onchange = syncSite;
    const save = async (patch, msg, btn) => {
      busy(btn, true);
      const { error } = await S.sb.from('profiles').update(patch).eq('id', u.id);
      busy(btn, false);
      if (error) return toast(errMsg(error), true);
      closeSheet(); toast(msg); render();
    };
    const go2 = $('#u-go', root);
    if (go2) go2.onclick = (e) => save({ role: roleSel.value, site_id: roleSel.value === 'secteur' ? null : Number($('#u-site', root).value), active: true }, u.active ? 'Compte modifié' : 'Accès validé', e.target);
    const off = $('#u-off', root);
    if (off) off.onclick = (e) => save({ active: false }, 'Accès retiré', e.target);
    const del = $('#u-del', root);
    if (del) del.onclick = async (e) => {
      busy(e.target, true);
      const { error } = await S.sb.from('profiles').delete().eq('id', u.id);
      busy(e.target, false);
      if (error) return toast(errMsg(error), true);
      closeSheet(); toast('Compte refusé'); render();
    };
  });
}

// ---------------------------------------------------------------------
// COMPTE
// ---------------------------------------------------------------------
async function renderAccount() {
  main.innerHTML = `
    ${isResp() ? backLink('#/plus', 'Plus') : ''}
    <div class="page-head"><h1>Mon compte</h1><p class="muted">${esc(ROLE_LABEL[role()])}${S.me.site_id ? ' · ' + esc(siteName(S.me.site_id)) : ''}</p></div>
    <form class="card stack" id="ac-name-f" novalidate>
      <div class="field"><label for="ac-name">Nom affiché</label><input type="text" id="ac-name" value="${esc(S.me.full_name)}"></div>
      <button type="submit" class="btn">Enregistrer le nom</button>
    </form>
    <form class="card stack" id="ac-pw-f" novalidate>
      <div class="field"><label for="ac-pw">Nouveau mot de passe</label><input type="password" id="ac-pw" autocomplete="new-password" minlength="8"></div>
      <button type="submit" class="btn">Changer le mot de passe</button>
    </form>
    <button type="button" class="btn danger block" id="ac-out">Se déconnecter</button>
    <p class="small muted">Pour installer l'application sur l'écran d'accueil : dans le navigateur, menu Partager (iPhone) ou ⋮ (Android), puis « Sur l'écran d'accueil ».</p>`;
  $('#ac-name-f').onsubmit = async (e) => {
    e.preventDefault();
    const n = $('#ac-name').value.trim();
    if (!n) return toast('Indiquez un nom.', true);
    const { error } = await S.sb.from('profiles').update({ full_name: n }).eq('id', S.me.id);
    if (error) return toast(errMsg(error), true);
    S.me.full_name = n; if (S.profiles[S.me.id]) S.profiles[S.me.id].full_name = n;
    toast('Nom enregistré');
  };
  $('#ac-pw-f').onsubmit = async (e) => {
    e.preventDefault();
    const pw = $('#ac-pw').value;
    if (pw.length < 8) return toast('8 caractères minimum.', true);
    const { error } = await S.sb.auth.updateUser({ password: pw });
    if (error) return toast(errMsg(error), true);
    $('#ac-pw').value = '';
    toast('Mot de passe changé');
  };
  $('#ac-out').onclick = async () => { await S.sb.auth.signOut(); location.hash = ''; location.reload(); };
}

// ---------------------------------------------------------------------
// CONNEXION
// ---------------------------------------------------------------------
function authShell(inner) {
  $('#topbar').hidden = true; $('#tabs').hidden = true;
  main.innerHTML = `<div class="auth"><div class="auth-brand"><span class="brand-mark" aria-hidden="true"></span>
    <h1>Stock Entretien</h1><p class="muted">Produits d'entretien · Centre sportif Nelson Mandela et complexe de l'Aar</p></div>${inner}</div>`;
}

function renderConfigMissing() {
  authShell(`<div class="notice">L'application n'est pas encore reliée à sa base de données. Ouvrez le fichier <span class="kbd">config.js</span> et collez l'adresse et la clé publique de votre projet Supabase (voir le guide d'installation).</div>`);
}

function renderAuth(mode = 'login') {
  if (mode === 'recovery') {
    authShell(`<form class="card stack" id="rc-f" novalidate><h2>Nouveau mot de passe</h2>
      <div class="field"><label for="rc-pw">Mot de passe (8 caractères minimum)</label><input type="password" id="rc-pw" autocomplete="new-password"></div>
      <button type="submit" class="btn primary">Enregistrer</button></form>`);
    $('#rc-f').onsubmit = async (e) => {
      e.preventDefault();
      const pw = $('#rc-pw').value;
      if (pw.length < 8) return toast('8 caractères minimum.', true);
      const { error } = await S.sb.auth.updateUser({ password: pw });
      if (error) return toast(errMsg(error), true);
      toast('Mot de passe enregistré');
      afterLogin();
    };
    return;
  }
  const signup = mode === 'signup';
  authShell(`
    <div class="seg" id="au-mode"><button type="button" data-m="login" aria-pressed="${!signup}">Se connecter</button><button type="button" data-m="signup" aria-pressed="${signup}">Créer mon compte</button></div>
    <form class="stack" id="au-f" novalidate>
      ${signup ? '<div class="field"><label for="au-name">Prénom et nom</label><input type="text" id="au-name" autocomplete="name" required></div>' : ''}
      <div class="field"><label for="au-email">Adresse e-mail</label><input type="email" id="au-email" autocomplete="email" inputmode="email" autocapitalize="none" required></div>
      <div class="field"><label for="au-pw">Mot de passe${signup ? ' (8 caractères minimum)' : ''}</label><input type="password" id="au-pw" autocomplete="${signup ? 'new-password' : 'current-password'}" required></div>
      <button type="submit" class="btn primary block" id="au-go">${signup ? 'Créer mon compte' : 'Se connecter'}</button>
      ${signup ? '<p class="small muted">Votre accès sera activé par le responsable de secteur.</p>' : '<button type="button" class="btn ghost block" id="au-forgot">Mot de passe oublié</button>'}
    </form>`);
  $('#au-mode').onclick = (e) => { const b = e.target.closest('[data-m]'); if (b) renderAuth(b.dataset.m); };
  const forgot = $('#au-forgot');
  if (forgot) forgot.onclick = async () => {
    const email = $('#au-email').value.trim();
    if (!email) return toast('Saisissez d\'abord votre adresse e-mail.', true);
    const { error } = await S.sb.auth.resetPasswordForEmail(email, { redirectTo: appBaseUrl() });
    if (error) return toast(errMsg(error), true);
    toast('Un lien pour changer le mot de passe a été envoyé par e-mail.');
  };
  $('#au-f').onsubmit = async (e) => {
    e.preventDefault();
    const email = $('#au-email').value.trim(), pw = $('#au-pw').value;
    if (!/^\S+@\S+\.\S+$/.test(email)) return toast('Adresse e-mail invalide.', true);
    const btn = $('#au-go');
    if (signup) {
      const name = $('#au-name').value.trim();
      if (!name) return toast('Indiquez votre prénom et votre nom.', true);
      if (pw.length < 8) return toast('Le mot de passe doit contenir au moins 8 caractères.', true);
      busy(btn, true, 'Création…');
      const { data, error } = await S.sb.auth.signUp({ email, password: pw, options: { data: { full_name: name }, emailRedirectTo: appBaseUrl() } });
      busy(btn, false);
      if (error) return toast(errMsg(error), true);
      if (!data.session) {
        authShell('<div class="card stack"><h2>Compte créé</h2><p>Confirmez votre adresse avec le lien reçu par e-mail, puis connectez-vous.</p><button type="button" class="btn primary" id="au-back">Se connecter</button></div>');
        $('#au-back').onclick = () => renderAuth('login');
        return;
      }
      return afterLogin();
    }
    busy(btn, true, 'Connexion…');
    const { error } = await S.sb.auth.signInWithPassword({ email, password: pw });
    busy(btn, false);
    if (error) return toast(errMsg(error), true);
    afterLogin();
  };
}

function renderWaiting(kind) {
  const msg = {
    pending: ['Compte en attente', 'Votre compte est créé. Le responsable de secteur doit maintenant valider votre accès et vous attribuer un site. Revenez ici ensuite.'],
    nosite: ['Site à attribuer', 'Votre accès est validé, mais aucun site ne vous est encore attribué. Prévenez le responsable de secteur.'],
    removed: ['Accès refusé', 'Ce compte n\'a pas accès à l\'application. Rapprochez-vous du responsable de secteur.'],
  }[kind];
  authShell(`<div class="card stack"><h2>${msg[0]}</h2><p>${msg[1]}</p>
    <button type="button" class="btn primary" id="w-retry">Vérifier à nouveau</button>
    <button type="button" class="btn ghost" id="w-out">Se déconnecter</button></div>`);
  $('#w-retry').onclick = () => afterLogin();
  $('#w-out').onclick = async () => { await S.sb.auth.signOut(); renderAuth(); };
}

let pollTimer = 0;
async function afterLogin() {
  const { data: { user } } = await S.sb.auth.getUser();
  if (!user) return renderAuth();
  const { data: me, error } = await S.sb.from('profiles').select('*').eq('id', user.id).maybeSingle();
  if (error) { authShell(`<div class="notice danger">${esc(errMsg(error))}</div>`); return; }
  if (!me) return renderWaiting('removed');
  if (!me.active) return renderWaiting('pending');
  if (me.role !== 'secteur' && !me.site_id) return renderWaiting('nosite');
  S.me = me;
  main.innerHTML = '<div class="loading">Chargement…</div>';
  try {
    await loadCore();
  } catch (e) {
    authShell(`<div class="notice danger">${esc(errMsg(e))}</div><button type="button" class="btn" onclick="location.reload()">Réessayer</button>`);
    return;
  }
  S.site = me.role === 'secteur' ? (S.sites.some((s) => s.id === lsGet('stock.site', 1)) ? lsGet('stock.site', 1) : S.sites[0]?.id) : me.site_id;
  renderChrome();
  if (!location.hash || location.hash === '#' || location.hash === '#/') location.replace('#/accueil');
  render();
  refreshBadges();
  clearInterval(pollTimer);
  pollTimer = setInterval(() => { if (document.visibilityState === 'visible') refreshBadges(); }, 45000);
}
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible' && S.me) refreshBadges(); });

// ---------------------------------------------------------------------
// Démarrage
// ---------------------------------------------------------------------
async function boot() {
  if (!CFG.supabaseUrl || /COLLER/.test(CFG.supabaseUrl) || !CFG.supabaseAnonKey || /COLLER/.test(CFG.supabaseAnonKey)) return renderConfigMissing();
  if (!window.supabase) { authShell('<div class="notice danger">Impossible de charger l\'application. Vérifiez la connexion Internet, puis rechargez la page.</div>'); return; }
  S.sb = window.supabase.createClient(CFG.supabaseUrl, CFG.supabaseAnonKey, { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true } });
  let recovering = /type=recovery/.test(location.hash);
  S.sb.auth.onAuthStateChange((event) => {
    if (event === 'PASSWORD_RECOVERY') { recovering = true; renderAuth('recovery'); }
  });
  const { data: { session } } = await S.sb.auth.getSession();
  if (recovering) return renderAuth('recovery');
  if (!session) return renderAuth();
  afterLogin();
}
boot();
})();
